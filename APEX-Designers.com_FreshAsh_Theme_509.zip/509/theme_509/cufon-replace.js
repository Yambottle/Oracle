Cufon.replace('h1, h2, h3, .phone span', { fontFamily: 'Nilland-ExtraBold' });
Cufon.replace('h3.green', {fontFamily: 'Nilland-ExtraBold' , color: '#73c30f'});
Cufon.replace('h1 strong', { fontFamily: 'Nilland-Black' });
Cufon.replace('#header .tabs ul li a', { fontFamily: 'Kozuka Gothic Pr6N AJ16 OpenType 500', hover:true });
Cufon.replace('#header .tabs ul li a span', { fontFamily: 'Kozuka Gothic Pr6N AJ16 OpenType 300', textShadow:'0 0 #aaa19d' });
Cufon.replace('#header .tabs ul li a', { fontFamily: 'Kozuka Gothic Pr6N AJ16 OpenType 500', hover:true });

