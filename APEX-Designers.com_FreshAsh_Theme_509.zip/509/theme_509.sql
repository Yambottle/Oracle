set define off
set verify off
set serveroutput on size 1000000
set feedback off
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
begin wwv_flow.g_import_in_progress := true; end; 
/
 
--       AAAA       PPPPP   EEEEEE  XX      XX
--      AA  AA      PP  PP  EE       XX    XX
--     AA    AA     PP  PP  EE        XX  XX
--    AAAAAAAAAA    PPPPP   EEEE       XXXX
--   AA        AA   PP      EE        XX  XX
--  AA          AA  PP      EE       XX    XX
--  AA          AA  PP      EEEEEE  XX      XX
prompt  Set Credentials...
 
begin
 
  -- Assumes you are running the script connected to SQL*Plus as the Oracle user APEX_040000 or as the owner (parsing schema) of the application.
  wwv_flow_api.set_security_group_id(p_security_group_id=>nvl(wwv_flow_application_install.get_workspace_id,6801409874193032));
 
end;
/

begin wwv_flow.g_import_in_progress := true; end;
/
begin 

select value into wwv_flow_api.g_nls_numeric_chars from nls_session_parameters where parameter='NLS_NUMERIC_CHARACTERS';

end;

/
begin execute immediate 'alter session set nls_numeric_characters=''.,''';

end;

/
begin wwv_flow.g_browser_language := 'en'; end;
/
prompt  Check Compatibility...
 
begin
 
-- This date identifies the minimum version required to import this file.
wwv_flow_api.set_version(p_version_yyyy_mm_dd=>'2010.05.13');
 
end;
/

prompt  Set Application ID...
 
begin
 
   -- SET APPLICATION ID
   wwv_flow.g_flow_id := nvl(wwv_flow_application_install.get_application_id,509);
   wwv_flow_api.g_id_offset := nvl(wwv_flow_application_install.get_offset,0);
null;
 
end;
/

--application/themes/106
 
begin
 
    wwv_flow.g_flow_theme_id := 106;
null;
 
end;
/

 
--
prompt  ...theme : 106
--
prompt  ...remove existing theme ...
 
begin
 
 wwv_flow_api.delete_theme(p_flow_id=> wwv_flow.g_flow_id , p_theme_id=>wwv_flow.g_flow_theme_id ,p_import=>'Y');
null;
 
end;
/

prompt  ...page templates for application: 509
--
--application/shared_components/user_interface/templates/page/no_tabs
prompt  ......Page template 7491322933412975
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'||chr(10)||
''||chr(10)||
'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="&BROWSER_LANGUAGE.">'||chr(10)||
'<head>'||chr(10)||
'<title>#TITLE#</title>'||chr(10)||
''||chr(10)||
'<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'||chr(10)||
'<meta http-equiv="Content-Style-Type" content="text/css" />'||chr(10)||
''||chr(10)||
'#HEAD#'||chr(10)||
'<link href="#IMAGE_PREFIX#themes/the';

c1:=c1||'me_509/style.css" rel="stylesheet" type="text/css" />'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-yui.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-replace.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/maxheight.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland_400.font.js" typ';

c1:=c1||'e="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-Black_900.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-ExtraBold_800.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_300.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/t';

c1:=c1||'heme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_500.font.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/script.js" type="text/javascript"></script>'||chr(10)||
'<link rel="shortcut icon" href="#IMAGE_PREFIX#themes/theme_509/favicon.ico" type="image/x-icon" />'||chr(10)||
''||chr(10)||
'</head>'||chr(10)||
'<body id="no-tabs" #ONLOAD# onload="new ElementMaxHeight()">'||chr(10)||
'#FORM_OPEN#';

c2:=c2||'   <!-- FOOTER -->'||chr(10)||
'   <div id="footer">'||chr(10)||
'      #REGION_POSITION_08#'||chr(10)||
'      <div style="position: absolute; top: 10px; right: 30px;"><a href="http://www.apex-designers.com" title="APEX-Designers.com">'||chr(10)||
'      <img src="#IMAGE_PREFIX#themes/theme_509/ad_logo.png" alt="APEX-Designers.com"/></a>'||chr(10)||
'      </div>'||chr(10)||
'   </div>'||chr(10)||
'</div>'||chr(10)||
'#FORM_CLOSE# '||chr(10)||
'<script type="text/javascript"> Cufon.now(); </script>'||chr(10)||
'</body>'||chr(10)||
'</html>';

c3:=c3||'<div id="main">'||chr(10)||
'   <!-- HEADER -->'||chr(10)||
'   <div id="header">'||chr(10)||
'      <div class="left">'||chr(10)||
'         <div class="right">'||chr(10)||
'            <div class="logo-nav wrapper">'||chr(10)||
'			#LOGO#'||chr(10)||
'               <h1><a href="#HOME_LINK#" >APEX theme made by APEX-Designers.com</a></h1>'||chr(10)||
'               <ul>#NAVIGATION_BAR#<li class="user">&APP_USER.</li></ul>'||chr(10)||
'            </div>'||chr(10)||
'            <div class="breadcrumb wrapper">'||chr(10)||
'           ';

c3:=c3||'    #REGION_POSITION_01#'||chr(10)||
'               #REGION_POSITION_07#'||chr(10)||
'            </div>'||chr(10)||
'         </div>'||chr(10)||
'      </div>'||chr(10)||
'   </div>   <!-- /HEADER -->'||chr(10)||
''||chr(10)||
'   <div id="messages">#NOTIFICATION_MESSAGE##SUCCESS_MESSAGE#</div>'||chr(10)||
''||chr(10)||
'   <!-- CONTENT -->'||chr(10)||
'   <div id="content">'||chr(10)||
'         <div class="wrapper">'||chr(10)||
'            #REGION_POSITION_04#'||chr(10)||
'            <div class="box-body">'||chr(10)||
'             #BOX_BODY#'||chr(10)||
'             #REGION_POSITI';

c3:=c3||'ON_02#            '||chr(10)||
'             #REGION_POSITION_03#'||chr(10)||
'            </div>'||chr(10)||
'            #REGION_POSITION_05#'||chr(10)||
'            #REGION_POSITION_06#'||chr(10)||
'         </div>'||chr(10)||
'   </div>   <!-- /CONTENT -->';

wwv_flow_api.create_template(
  p_id=> 7491322933412975 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'No Tabs',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="success" id="MESSAGE">'||chr(10)||
'<img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')" alt="Close" />#SUCCESS_MESSAGE#'||chr(10)||
'</div>',
  p_current_tab=> '',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="notification" id="MESSAGE"><img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')"  alt="Close" />#MESSAGE#</div>',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '<li><a href="#LINK#">#TEXT#</a></li>',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="5" align="left"',
  p_breadcrumb_def_reg_pos => 'REGION_POSITION_01',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 3,
  p_template_comment => '');
end;
 
null;
 
end;
/

--application/shared_components/user_interface/templates/page/no_tabs_with_sidebar
prompt  ......Page template 7492200779482334
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'||chr(10)||
''||chr(10)||
'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="&BROWSER_LANGUAGE.">'||chr(10)||
'<head>'||chr(10)||
'<title>#TITLE#</title>'||chr(10)||
''||chr(10)||
'<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'||chr(10)||
'<meta http-equiv="Content-Style-Type" content="text/css" />'||chr(10)||
''||chr(10)||
'#HEAD#'||chr(10)||
'<link href="#IMAGE_PREFIX#themes/the';

c1:=c1||'me_509/style.css" rel="stylesheet" type="text/css" />'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-yui.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-replace.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/maxheight.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland_400.font.js" typ';

c1:=c1||'e="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-Black_900.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-ExtraBold_800.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_300.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/t';

c1:=c1||'heme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_500.font.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/script.js" type="text/javascript"></script>'||chr(10)||
'<link rel="shortcut icon" href="#IMAGE_PREFIX#themes/theme_509/favicon.ico" type="image/x-icon" />'||chr(10)||
''||chr(10)||
'</head>'||chr(10)||
'<body id="no-tabs-sidebar" #ONLOAD# onload="new ElementMaxHeight()">'||chr(10)||
'#FORM_OPEN#';

c2:=c2||'   <!-- FOOTER -->'||chr(10)||
'   <div id="footer">'||chr(10)||
'      #REGION_POSITION_08#'||chr(10)||
'      <div style="position: absolute; top: 10px; right: 30px;"><a href="http://www.apex-designers.com" title="APEX-Designers.com">'||chr(10)||
'      <img src="#IMAGE_PREFIX#themes/theme_509/ad_logo.png" alt="APEX-Designers.com"/></a>'||chr(10)||
'      </div>'||chr(10)||
'   </div>'||chr(10)||
'</div>'||chr(10)||
'#FORM_CLOSE# '||chr(10)||
'<script type="text/javascript"> Cufon.now(); </script>'||chr(10)||
'</body>'||chr(10)||
'</html>';

c3:=c3||'<div id="main">'||chr(10)||
'   <!-- HEADER -->'||chr(10)||
'   <div id="header">'||chr(10)||
'      <div class="left">'||chr(10)||
'         <div class="right">'||chr(10)||
'            <div class="logo-nav wrapper">'||chr(10)||
'			#LOGO#'||chr(10)||
'               <h1><a href="#HOME_LINK#" >APEX theme made by APEX-Designers.com</a></h1>'||chr(10)||
'               <ul>#NAVIGATION_BAR#<li class="user">&APP_USER.</li></ul>'||chr(10)||
'            </div>'||chr(10)||
'            <div class="breadcrumb wrapper">'||chr(10)||
'           ';

c3:=c3||'    #REGION_POSITION_01#'||chr(10)||
'               #REGION_POSITION_07#'||chr(10)||
'            </div>'||chr(10)||
'         </div>'||chr(10)||
'      </div>'||chr(10)||
'   </div>   <!-- /HEADER -->'||chr(10)||
''||chr(10)||
'   <div id="messages">#NOTIFICATION_MESSAGE##SUCCESS_MESSAGE#</div>'||chr(10)||
''||chr(10)||
'   <!-- CONTENT -->'||chr(10)||
'   <div id="content">'||chr(10)||
'         <div class="wrapper">'||chr(10)||
'            #REGION_POSITION_04#'||chr(10)||
'            <div class="box-body">'||chr(10)||
'             #BOX_BODY#'||chr(10)||
'            #REGION_POSITIO';

c3:=c3||'N_03#'||chr(10)||
'            </div>'||chr(10)||
'            <div class="side-box">'||chr(10)||
'             #REGION_POSITION_02#'||chr(10)||
'            </div>'||chr(10)||
'            #REGION_POSITION_05#'||chr(10)||
'            #REGION_POSITION_06#'||chr(10)||
''||chr(10)||
'         </div>'||chr(10)||
'   </div>   <!-- /CONTENT -->';

wwv_flow_api.create_template(
  p_id=> 7492200779482334 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'No Tabs with Sidebar',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="success" id="MESSAGE">'||chr(10)||
'<img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')" alt="Close" />#SUCCESS_MESSAGE#'||chr(10)||
'</div>',
  p_current_tab=> '<li><a href="#TAB_LINK#">#TAB_LABEL#</a></li>',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '<li><a href="#TAB_LINK#">#TAB_LABEL#</a></li>',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="notification" id="MESSAGE"><img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')"  alt="Close" />#MESSAGE#</div>',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '<li><a href="#LINK#">#TEXT#</a></li>',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="5" align="left"',
  p_sidebar_def_reg_pos => 'REGION_POSITION_02',
  p_breadcrumb_def_reg_pos => 'REGION_POSITION_01',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 17,
  p_template_comment => '');
end;
 
null;
 
end;
/

--application/shared_components/user_interface/templates/page/login
prompt  ......Page template 21491530007853426
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'||chr(10)||
''||chr(10)||
'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="&BROWSER_LANGUAGE.">'||chr(10)||
'<head>'||chr(10)||
'<title>#TITLE#</title>'||chr(10)||
''||chr(10)||
'<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'||chr(10)||
'<meta http-equiv="Content-Style-Type" content="text/css" />'||chr(10)||
''||chr(10)||
'#HEAD#'||chr(10)||
'<link href="#IMAGE_PREFIX#themes/the';

c1:=c1||'me_509/style.css" rel="stylesheet" type="text/css" />'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-yui.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-replace.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/maxheight.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland_400.font.js" typ';

c1:=c1||'e="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-Black_900.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-ExtraBold_800.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_300.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/t';

c1:=c1||'heme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_500.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/jquery.faded.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/jcarousellite.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/script.js" type="text/javascript"></script>'||chr(10)||
'<link rel="shortcut icon" href="#I';

c1:=c1||'MAGE_PREFIX#themes/theme_509/favicon.ico" type="image/x-icon" />'||chr(10)||
''||chr(10)||
'</head>'||chr(10)||
'<body id="login" #ONLOAD# onload="new ElementMaxHeight()">'||chr(10)||
'#FORM_OPEN#';

c2:=c2||'   <!-- FOOTER -->'||chr(10)||
'   <div id="footer">'||chr(10)||
'      #REGION_POSITION_08#'||chr(10)||
'      <div style="position: absolute; top: 10px; right: 30px;"><a href="http://www.apex-designers.com" title="APEX-Designers.com">'||chr(10)||
'      <img src="#IMAGE_PREFIX#themes/theme_509/ad_logo.png" alt="APEX-Designers.com"/></a>'||chr(10)||
'      </div>'||chr(10)||
'   </div>'||chr(10)||
'</div>'||chr(10)||
'#FORM_CLOSE# '||chr(10)||
'<script type="text/javascript"> Cufon.now(); </script>'||chr(10)||
'</body>'||chr(10)||
'</html>'||chr(10)||
'';

c3:=c3||'<div id="main">'||chr(10)||
'   <!-- HEADER -->'||chr(10)||
'   <div id="header">'||chr(10)||
'      <div class="left">'||chr(10)||
'         <div class="right">'||chr(10)||
'            <div class="logo-nav wrapper">'||chr(10)||
'			#LOGO#'||chr(10)||
'               <h1><a href="index.html" ><strong>APEX-Designers.com</strong> Tematy graficzne dla aplikacji w Oracle APEX.</a></h1>'||chr(10)||
'               <ul>#NAVIGATION_BAR#</ul>'||chr(10)||
'            </div>'||chr(10)||
'            <div class="breadcrumb wrapper">'||chr(10)||
'';

c3:=c3||'               #REGION_POSITION_01#'||chr(10)||
'               #REGION_POSITION_07#'||chr(10)||
'            </div>'||chr(10)||
'         </div>'||chr(10)||
'      </div>'||chr(10)||
'   </div>   <!-- /HEADER -->'||chr(10)||
''||chr(10)||
'   <div id="messages">#NOTIFICATION_MESSAGE##SUCCESS_MESSAGE#</div>'||chr(10)||
''||chr(10)||
'   <!-- CONTENT -->'||chr(10)||
'   <div id="content">'||chr(10)||
'         <div class="wrapper">'||chr(10)||
'            <div class="box-body">'||chr(10)||
'             #BOX_BODY#'||chr(10)||
'             #REGION_POSITION_02#            '||chr(10)||
'   ';

c3:=c3||'          #REGION_POSITION_03#'||chr(10)||
'            </div>'||chr(10)||
'            #REGION_POSITION_04#'||chr(10)||
'            #REGION_POSITION_05#'||chr(10)||
'            #REGION_POSITION_06#'||chr(10)||
'         </div>'||chr(10)||
'   </div>   <!-- /CONTENT -->';

wwv_flow_api.create_template(
  p_id=> 21491530007853426 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Login',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="success" id="MESSAGE">'||chr(10)||
'<img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')" alt="Close" />#SUCCESS_MESSAGE#'||chr(10)||
'</div>',
  p_current_tab=> '',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="notification" id="MESSAGE"><img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')"  alt="Close" />#MESSAGE#</div>',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '<li><a href="#LINK#">#TEXT#</a></li>',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 6,
  p_template_comment => '');
end;
 
null;
 
end;
/

--application/shared_components/user_interface/templates/page/one_level_tabs
prompt  ......Page template 21492329643853433
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'||chr(10)||
''||chr(10)||
'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="&BROWSER_LANGUAGE.">'||chr(10)||
'<head>'||chr(10)||
'<title>#TITLE#</title>'||chr(10)||
''||chr(10)||
'<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'||chr(10)||
'<meta http-equiv="Content-Style-Type" content="text/css" />'||chr(10)||
''||chr(10)||
'#HEAD#'||chr(10)||
'<link href="#IMAGE_PREFIX#themes/the';

c1:=c1||'me_509/style.css" rel="stylesheet" type="text/css" />'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-yui.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-replace.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/maxheight.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland_400.font.js" typ';

c1:=c1||'e="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-Black_900.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-ExtraBold_800.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_300.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/t';

c1:=c1||'heme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_500.font.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/script.js" type="text/javascript"></script>'||chr(10)||
'<link rel="shortcut icon" href="#IMAGE_PREFIX#themes/theme_509/favicon.ico" type="image/x-icon" />'||chr(10)||
''||chr(10)||
'</head>'||chr(10)||
'<body id="one-level" #ONLOAD# onload="new ElementMaxHeight()">'||chr(10)||
'#FORM_OPEN#';

c2:=c2||'   <!-- FOOTER -->'||chr(10)||
'   <div id="footer">'||chr(10)||
'      #REGION_POSITION_08#'||chr(10)||
'      <div style="position: absolute; top: 10px; right: 30px;"><a href="http://www.apex-designers.com" title="APEX-Designers.com">'||chr(10)||
'      <img src="#IMAGE_PREFIX#themes/theme_509/ad_logo.png" alt="APEX-Designers.com"/></a>'||chr(10)||
'      </div>'||chr(10)||
'   </div>'||chr(10)||
'</div>'||chr(10)||
'#FORM_CLOSE# '||chr(10)||
'<script type="text/javascript"> Cufon.now(); </script>'||chr(10)||
'</body>'||chr(10)||
'</html>';

c3:=c3||'<div id="main">'||chr(10)||
'   <!-- HEADER -->'||chr(10)||
'   <div id="header">'||chr(10)||
'      <div class="left">'||chr(10)||
'         <div class="right">'||chr(10)||
'            <div class="logo-nav wrapper">'||chr(10)||
'			#LOGO#'||chr(10)||
'               <h1><a href="#HOME_LINK#" >APEX theme made by APEX-Designers.com</a></h1>'||chr(10)||
'               <ul>#NAVIGATION_BAR#<li class="user">&APP_USER.</li></ul>'||chr(10)||
'            </div>'||chr(10)||
'            <div class="tabs">'||chr(10)||
'               <ul class=';

c3:=c3||'"wrapper">#TAB_CELLS#</ul>'||chr(10)||
'            </div>'||chr(10)||
'            <div class="breadcrumb wrapper">'||chr(10)||
'               #REGION_POSITION_01#'||chr(10)||
'               #REGION_POSITION_07#'||chr(10)||
'            </div>'||chr(10)||
'         </div>'||chr(10)||
'      </div>'||chr(10)||
'   </div>   <!-- /HEADER -->'||chr(10)||
''||chr(10)||
'   <div id="messages">#NOTIFICATION_MESSAGE##SUCCESS_MESSAGE#</div>'||chr(10)||
''||chr(10)||
'   <!-- CONTENT -->'||chr(10)||
'   <div id="content">'||chr(10)||
'         <div class="wrapper">'||chr(10)||
'            #REGI';

c3:=c3||'ON_POSITION_04#'||chr(10)||
'            <div class="box-body">'||chr(10)||
'             #BOX_BODY#'||chr(10)||
'             #REGION_POSITION_02#            '||chr(10)||
'             #REGION_POSITION_03#'||chr(10)||
'            </div>'||chr(10)||
'            #REGION_POSITION_05#'||chr(10)||
'            #REGION_POSITION_06#'||chr(10)||
'         </div>'||chr(10)||
'   </div>   <!-- /CONTENT -->';

wwv_flow_api.create_template(
  p_id=> 21492329643853433 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'One Level Tabs',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="success" id="MESSAGE">'||chr(10)||
'<img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')" alt="Close" />#SUCCESS_MESSAGE#'||chr(10)||
'</div>',
  p_current_tab=> '<li>#TAB_IMAGE#<a href="#TAB_LINK#">#TAB_LABEL#</a></li>',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '<li>#TAB_IMAGE#<a href="#TAB_LINK#">#TAB_LABEL#</a></li>',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="notification" id="MESSAGE"><img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')"  alt="Close" />#MESSAGE#</div>',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '<li><a href="#LINK#">#TEXT#</a></li>',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="5" align="left"',
  p_breadcrumb_def_reg_pos => 'REGION_POSITION_01',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 1,
  p_template_comment => '');
end;
 
null;
 
end;
/

--application/shared_components/user_interface/templates/page/popup
prompt  ......Page template 21492939699853435
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'||chr(10)||
''||chr(10)||
'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="&BROWSER_LANGUAGE.">'||chr(10)||
'<head>'||chr(10)||
'<title>#TITLE#</title>'||chr(10)||
''||chr(10)||
'<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'||chr(10)||
'<meta http-equiv="Content-Style-Type" content="text/css" />'||chr(10)||
''||chr(10)||
'#HEAD#'||chr(10)||
'<link href="#IMAGE_PREFIX#themes/the';

c1:=c1||'me_509/style.css" rel="stylesheet" type="text/css" />'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-yui.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-replace.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/maxheight.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland_400.font.js" typ';

c1:=c1||'e="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-Black_900.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-ExtraBold_800.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_300.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/t';

c1:=c1||'heme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_500.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/jquery.faded.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/jcarousellite.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/script.js" type="text/javascript"></script>'||chr(10)||
'<link rel="shortcut icon" href="#I';

c1:=c1||'MAGE_PREFIX#themes/theme_509/favicon.ico" type="image/x-icon" />'||chr(10)||
''||chr(10)||
'</head>'||chr(10)||
'<body id="popup" #ONLOAD# onload="new ElementMaxHeight()">'||chr(10)||
'#FORM_OPEN#';

c2:=c2||'   <!-- FOOTER -->'||chr(10)||
'   <div id="footer">'||chr(10)||
'      #REGION_POSITION_08#'||chr(10)||
'      <div style="position: absolute; top: 10px; right: 30px;"><a href="http://www.apex-designers.com" title="APEX-Designers.com">'||chr(10)||
'      <img src="#IMAGE_PREFIX#themes/theme_509/ad_logo.png" alt="APEX-Designers.com"/></a>'||chr(10)||
'      </div>'||chr(10)||
'   </div>'||chr(10)||
'</div>'||chr(10)||
'#FORM_CLOSE# '||chr(10)||
'<script type="text/javascript"> Cufon.now(); </script>'||chr(10)||
'</body>'||chr(10)||
'</html>';

c3:=c3||'<div id="main">'||chr(10)||
'   <!-- HEADER -->'||chr(10)||
'   <div id="header">'||chr(10)||
'      <div class="left">'||chr(10)||
'         <div class="right">'||chr(10)||
'            <div class="breadcrumb wrapper">'||chr(10)||
'               #REGION_POSITION_01#'||chr(10)||
'               #REGION_POSITION_07#'||chr(10)||
'            </div>'||chr(10)||
'         </div>'||chr(10)||
'      </div>'||chr(10)||
'   </div>   <!-- /HEADER -->'||chr(10)||
''||chr(10)||
'   <div id="messages">#NOTIFICATION_MESSAGE##SUCCESS_MESSAGE#</div>'||chr(10)||
''||chr(10)||
'   <!-- CONTENT -->'||chr(10)||
'   <di';

c3:=c3||'v id="content">'||chr(10)||
'         <div class="wrapper">'||chr(10)||
'            <div class="box-body">'||chr(10)||
'             #BOX_BODY#'||chr(10)||
'            #REGION_POSITION_03#'||chr(10)||
'            </div>'||chr(10)||
'            <div class="side-box">'||chr(10)||
'             #REGION_POSITION_02#'||chr(10)||
'            </div>'||chr(10)||
'            #REGION_POSITION_04#'||chr(10)||
'            #REGION_POSITION_05#'||chr(10)||
'            #REGION_POSITION_06#'||chr(10)||
''||chr(10)||
'         </div>'||chr(10)||
'   </div>   <!-- /CONTENT -->';

wwv_flow_api.create_template(
  p_id=> 21492939699853435 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Popup',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="success" id="MESSAGE">'||chr(10)||
'<img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')" alt="Close" />#SUCCESS_MESSAGE#'||chr(10)||
'</div>',
  p_current_tab=> '',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="notification" id="MESSAGE"><img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')"  alt="Close" />#MESSAGE#</div>',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '<li><a href="#LINK#">#TEXT#</a></li>',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 4,
  p_template_comment => '');
end;
 
null;
 
end;
/

--application/shared_components/user_interface/templates/page/printer_friendly
prompt  ......Page template 21493227602853435
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'||chr(10)||
''||chr(10)||
'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="&BROWSER_LANGUAGE.">'||chr(10)||
'<head>'||chr(10)||
'<title>#TITLE#</title>'||chr(10)||
''||chr(10)||
'<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'||chr(10)||
'<meta http-equiv="Content-Style-Type" content="text/css" />'||chr(10)||
''||chr(10)||
'#HEAD#'||chr(10)||
'<link href="#IMAGE_PREFIX#themes/the';

c1:=c1||'me_509/style.css" rel="stylesheet" type="text/css" />'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-yui.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-replace.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/maxheight.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland_400.font.js" typ';

c1:=c1||'e="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-Black_900.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-ExtraBold_800.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_300.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/t';

c1:=c1||'heme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_500.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/jquery.faded.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/jcarousellite.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/script.js" type="text/javascript"></script>'||chr(10)||
'<link rel="shortcut icon" href="#I';

c1:=c1||'MAGE_PREFIX#themes/theme_509/favicon.ico" type="image/x-icon" />'||chr(10)||
''||chr(10)||
'</head>'||chr(10)||
'<body id="printer-friendly" #ONLOAD# onload="new ElementMaxHeight()">'||chr(10)||
'#FORM_OPEN#';

c2:=c2||'   <!-- FOOTER -->'||chr(10)||
'   <div id="footer">'||chr(10)||
'      #REGION_POSITION_08#'||chr(10)||
'      <div style="position: absolute; top: 10px; right: 30px;"><a href="http://www.apex-designers.com" title="APEX-Designers.com">'||chr(10)||
'      <img src="#IMAGE_PREFIX#themes/theme_509/ad_logo.png" alt="APEX-Designers.com"/></a>'||chr(10)||
'      </div>'||chr(10)||
'   </div>'||chr(10)||
'</div>'||chr(10)||
'#FORM_CLOSE# '||chr(10)||
'<script type="text/javascript"> Cufon.now(); </script>'||chr(10)||
'</body>'||chr(10)||
'</html>';

c3:=c3||'<div id="main">'||chr(10)||
'   <!-- HEADER -->'||chr(10)||
'   <div id="header">'||chr(10)||
'      <div class="left">'||chr(10)||
'         <div class="right">'||chr(10)||
'            <div class="breadcrumb wrapper">'||chr(10)||
'               #REGION_POSITION_01#'||chr(10)||
'               #REGION_POSITION_07#'||chr(10)||
'            </div>'||chr(10)||
'         </div>'||chr(10)||
'      </div>'||chr(10)||
'   </div>   <!-- /HEADER -->'||chr(10)||
''||chr(10)||
'   <div id="messages">#NOTIFICATION_MESSAGE##SUCCESS_MESSAGE#</div>'||chr(10)||
''||chr(10)||
'   <!-- CONTENT -->'||chr(10)||
'   <di';

c3:=c3||'v id="content">'||chr(10)||
'         <div class="wrapper">'||chr(10)||
'            <div class="box-body">'||chr(10)||
'             #BOX_BODY#'||chr(10)||
'            #REGION_POSITION_03#'||chr(10)||
'            </div>'||chr(10)||
'            <div class="side-box">'||chr(10)||
'             #REGION_POSITION_02#'||chr(10)||
'            </div>'||chr(10)||
'            #REGION_POSITION_04#'||chr(10)||
'            #REGION_POSITION_05#'||chr(10)||
'            #REGION_POSITION_06#'||chr(10)||
''||chr(10)||
'         </div>'||chr(10)||
'   </div>   <!-- /CONTENT -->';

wwv_flow_api.create_template(
  p_id=> 21493227602853435 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'Printer Friendly',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="success" id="MESSAGE">'||chr(10)||
'<img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')" alt="Close" />#SUCCESS_MESSAGE#'||chr(10)||
'</div>',
  p_current_tab=> '',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="notification" id="MESSAGE"><img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')"  alt="Close" />#MESSAGE#</div>'||chr(10)||
'',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '<li><a href="#LINK#">#TEXT#</a></li>',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 5,
  p_template_comment => '3');
end;
 
null;
 
end;
/

--application/shared_components/user_interface/templates/page/one_level_tabs_with_sidebar
prompt  ......Page template 21513427523145713
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
c1:=c1||'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'||chr(10)||
''||chr(10)||
'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pl" lang="&BROWSER_LANGUAGE.">'||chr(10)||
'<head>'||chr(10)||
'<title>#TITLE#</title>'||chr(10)||
''||chr(10)||
'<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'||chr(10)||
'<meta http-equiv="Content-Style-Type" content="text/css" />'||chr(10)||
''||chr(10)||
'#HEAD#'||chr(10)||
'<link href="#IMAGE_PREFIX#themes/the';

c1:=c1||'me_509/style.css" rel="stylesheet" type="text/css" />'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-yui.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/cufon-replace.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/maxheight.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland_400.font.js" typ';

c1:=c1||'e="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-Black_900.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Nilland-ExtraBold_800.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_300.font.js" type="text/javascript"></script>'||chr(10)||
'<script src="#IMAGE_PREFIX#themes/t';

c1:=c1||'heme_509/Kozuka_Gothic_Pr6N_AJ16_OpenType_500.font.js" type="text/javascript"></script>'||chr(10)||
''||chr(10)||
'<script src="#IMAGE_PREFIX#themes/theme_509/script.js" type="text/javascript"></script>'||chr(10)||
'<link rel="shortcut icon" href="#IMAGE_PREFIX#themes/theme_509/favicon.ico" type="image/x-icon" />'||chr(10)||
''||chr(10)||
'</head>'||chr(10)||
'<body id="one-level-sidebar" #ONLOAD# onload="new ElementMaxHeight()">'||chr(10)||
'#FORM_OPEN#';

c2:=c2||'   <!-- FOOTER -->'||chr(10)||
'   <div id="footer">'||chr(10)||
'      #REGION_POSITION_08#'||chr(10)||
'      <div style="position: absolute; top: 10px; right: 30px;"><a href="http://www.apex-designers.com" title="APEX-Designers.com">'||chr(10)||
'      <img src="#IMAGE_PREFIX#themes/theme_509/ad_logo.png" alt="APEX-Designers.com"/></a>'||chr(10)||
'      </div>'||chr(10)||
'   </div>'||chr(10)||
'</div>'||chr(10)||
'#FORM_CLOSE# '||chr(10)||
'<script type="text/javascript"> Cufon.now(); </script>'||chr(10)||
'</body>'||chr(10)||
'</html>';

c3:=c3||'<div id="main">'||chr(10)||
'   <!-- HEADER -->'||chr(10)||
'   <div id="header">'||chr(10)||
'      <div class="left">'||chr(10)||
'         <div class="right">'||chr(10)||
'            <div class="logo-nav wrapper">'||chr(10)||
'			#LOGO#'||chr(10)||
'               <h1><a href="#HOME_LINK#" >APEX theme made by APEX-Designers.com</a></h1>'||chr(10)||
'               <ul>#NAVIGATION_BAR#<li class="user">&APP_USER.</li></ul>'||chr(10)||
'            </div>'||chr(10)||
'            <div class="tabs">'||chr(10)||
'               <ul class=';

c3:=c3||'"wrapper">#TAB_CELLS#</ul>'||chr(10)||
'            </div>'||chr(10)||
'            <div class="breadcrumb wrapper">'||chr(10)||
'               #REGION_POSITION_01#'||chr(10)||
'               #REGION_POSITION_07#'||chr(10)||
'            </div>'||chr(10)||
'         </div>'||chr(10)||
'      </div>'||chr(10)||
'   </div>   <!-- /HEADER -->'||chr(10)||
''||chr(10)||
'   <div id="messages">#NOTIFICATION_MESSAGE##SUCCESS_MESSAGE#</div>'||chr(10)||
''||chr(10)||
'   <!-- CONTENT -->'||chr(10)||
'   <div id="content">'||chr(10)||
'         <div class="wrapper">'||chr(10)||
'             #REG';

c3:=c3||'ION_POSITION_04#'||chr(10)||
'            <div class="box-body">'||chr(10)||
'             #BOX_BODY#'||chr(10)||
'            #REGION_POSITION_03#'||chr(10)||
'            </div>'||chr(10)||
'            <div class="side-box">'||chr(10)||
'             #REGION_POSITION_02#'||chr(10)||
'            </div>'||chr(10)||
''||chr(10)||
'            #REGION_POSITION_05#'||chr(10)||
'            #REGION_POSITION_06#'||chr(10)||
''||chr(10)||
'         </div>'||chr(10)||
'   </div>   <!-- /CONTENT -->';

wwv_flow_api.create_template(
  p_id=> 21513427523145713 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=> 'One Level Tabs with Sidebar',
  p_body_title=> '',
  p_header_template=> c1,
  p_box=> c3,
  p_footer_template=> c2,
  p_success_message=> '<div class="success" id="MESSAGE">'||chr(10)||
'<img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')" alt="Close" />#SUCCESS_MESSAGE#'||chr(10)||
'</div>',
  p_current_tab=> '<li>#TAB_IMAGE#<a href="#TAB_LINK#">#TAB_LABEL#</a></li>',
  p_current_tab_font_attr=> '',
  p_non_current_tab=> '<li>#TAB_IMAGE#<a href="#TAB_LINK#">#TAB_LABEL#</a></li>',
  p_non_current_tab_font_attr => '',
  p_top_current_tab=> '',
  p_top_current_tab_font_attr => '',
  p_top_non_curr_tab=> '',
  p_top_non_curr_tab_font_attr=> '',
  p_current_image_tab=> '',
  p_non_current_image_tab=> '',
  p_notification_message=> '<div class="notification" id="MESSAGE"><img src="#IMAGE_PREFIX#themes/theme_509/close.png" onclick="$x_Remove(''MESSAGE'')"  alt="Close" />#MESSAGE#</div>',
  p_navigation_bar=> '#BAR_BODY#',
  p_navbar_entry=> '<li><a href="#LINK#">#TEXT#</a></li>',
  p_app_tab_before_tabs=>'',
  p_app_tab_current_tab=>'',
  p_app_tab_non_current_tab=>'',
  p_app_tab_after_tabs=>'',
  p_region_table_cattributes=> ' summary="" cellpadding="0" border="0" cellspacing="5" align="left"',
  p_sidebar_def_reg_pos => 'REGION_POSITION_02',
  p_breadcrumb_def_reg_pos => 'REGION_POSITION_01',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 16,
  p_template_comment => '');
end;
 
null;
 
end;
/

prompt  ...button templates
--
--application/shared_components/user_interface/templates/button/button
prompt  ......Button Template 21508739389853477
declare
  t varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
t:=t||'<a href="#LINK#" class="button"><em><b>#LABEL#</b></em></a>';

wwv_flow_api.create_button_templates (
  p_id=>21508739389853477 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_template=>t,
  p_template_name=> 'Button',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 1,
  p_template_comment       => 'Standard Button');
end;
/
--application/shared_components/user_interface/templates/button/button_alternative_1
prompt  ......Button Template 21508938558853479
declare
  t varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
t:=t||'<a href="#LINK#" class="button button1"><em><b>#LABEL#</b></em></a>';

wwv_flow_api.create_button_templates (
  p_id=>21508938558853479 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_template=>t,
  p_template_name=> 'Button, Alternative 1',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 4,
  p_template_comment       => 'XP Square FFFFFF');
end;
/
--application/shared_components/user_interface/templates/button/button_alternative_2
prompt  ......Button Template 21509121341853479
declare
  t varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
t:=t||'<a href="#LINK#" class="button button2"><em><b>#LABEL#</b></em></a>';

wwv_flow_api.create_button_templates (
  p_id=>21509121341853479 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_template=>t,
  p_template_name=> 'Button, Alternative 2',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 5,
  p_template_comment       => 'Standard Button');
end;
/
--application/shared_components/user_interface/templates/button/button_alternative_3
prompt  ......Button Template 21509313736853479
declare
  t varchar2(32767) := null;
  l_clob clob;
  l_length number := 1;
begin
t:=t||'<a href="#LINK#" class="button button3"><em><b>#LABEL#</b></em></a>';

wwv_flow_api.create_button_templates (
  p_id=>21509313736853479 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_template=>t,
  p_template_name=> 'Button, Alternative 3',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 2,
  p_template_comment       => 'Standard Button');
end;
/
---------------------------------------
prompt  ...region templates
--
--application/shared_components/user_interface/templates/region/form_region_w_o_title_and_buttons
prompt  ......region template 7618931573919364
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 7618931573919364 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region-box">'||chr(10)||
'   <div class="border-right">'||chr(10)||
'      <div class="border-left">'||chr(10)||
'          <div class="left-top-corner">'||chr(10)||
'             <div class="right-top-corner">'||chr(10)||
''||chr(10)||
'		<div class="region form" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'		<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'		</div>'||chr(10)||
'		'||chr(10)||
'             </div>'||chr(10)||
'          </div>'||chr(10)||
'      </div>'||chr(10)||
'   </div>'||chr(10)||
'<div class="border-bot"><div'||
' class="left-bot-corner"><div class="right-bot-corner"></div></div></div>'||chr(10)||
'</div> '
 ,p_page_plug_template_name => 'Form Region w/o Title and Buttons'
 ,p_plug_table_bgcolor => '#f7f7e7'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 8
 ,p_plug_heading_bgcolor => '#f7f7e7'
 ,p_plug_font_size => '-1'
 ,p_template_comment => 'Red Theme'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 7618931573919364 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/borderless_region
prompt  ......region template 21494130008853440
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21494130008853440 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region borderless" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Borderless Region'
 ,p_plug_table_bgcolor => '#f7f7e7'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 7
 ,p_plug_heading_bgcolor => '#f7f7e7'
 ,p_plug_font_size => '-1'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21494130008853440 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/bracketed_region
prompt  ......region template 21494417169853441
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21494417169853441 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region bracketed" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Bracketed Region'
 ,p_plug_table_bgcolor => '#ffffff'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 18
 ,p_plug_heading_bgcolor => '#ffffff'
 ,p_plug_font_size => '-1'
 ,p_template_comment => 'Red Theme'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21494417169853441 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/breadcrumb_region
prompt  ......region template 21494745374853443
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21494745374853443 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES# class="fleft">#BODY#</div>'
 ,p_page_plug_template_name => 'Breadcrumb Region'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 6
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21494745374853443 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/button_region_with_title
prompt  ......region template 21495027512853443
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21495027512853443 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region buttonregionwtitle" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Button Region with Title'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 4
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21495027512853443 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/button_region_without_title
prompt  ......region template 21495315223853443
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21495315223853443 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region buttonregionwotitle" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Button Region without Title'
 ,p_plug_table_bgcolor => '#ffffff'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 17
 ,p_plug_heading_bgcolor => '#ffffff'
 ,p_plug_font_size => '-1'
 ,p_template_comment => 'Red Theme'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21495315223853443 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/form_region
prompt  ......region template 21496218029853444
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21496218029853444 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region-box">'||chr(10)||
'   <div class="border-right">'||chr(10)||
'      <div class="border-left">'||chr(10)||
'          <div class="left-top-corner">'||chr(10)||
'             <div class="right-top-corner">'||chr(10)||
''||chr(10)||
'		<div class="region form" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#><h3>#TITLE#</h3>'||chr(10)||
'		<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'		<div cla'||
'ss="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'		</div>'||chr(10)||
'		'||chr(10)||
'             </div>'||chr(10)||
'          </div>'||chr(10)||
'      </div>'||chr(10)||
'   </div>'||chr(10)||
'<div class="border-bot"><div class="left-bot-corner"><div class="right-bot-corner"></div></div></div>'||chr(10)||
'</div> '
 ,p_page_plug_template_name => 'Form Region'
 ,p_plug_table_bgcolor => '#f7f7e7'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 8
 ,p_plug_heading_bgcolor => '#f7f7e7'
 ,p_plug_font_size => '-1'
 ,p_template_comment => 'Red Theme'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21496218029853444 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/hide_and_show_region
prompt  ......region template 21496544900853444
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21496544900853444 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region hideandshow" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3 class="underline" onclick="$x_ToggleWithImage(''#REGION_ID#image'',''#REGION_ID#body'')" >#TITLE#</h3>'||chr(10)||
'<img src="#IMAGE_PREFIX#themes/theme_509/plus.gif" onclick="$x_ToggleWithImage(this,''#REGION_ID#body'')" id="#REGION_ID#image" alt="" />'||chr(10)||
''||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE'||
'##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
''||chr(10)||
'<div  id="#REGION_ID#body"  class="regionbody clear overflow" style="display:none;"> #BODY# </div>'||chr(10)||
'</div>'||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''||chr(10)||
''
 ,p_page_plug_template_name => 'Hide and Show Region'
 ,p_plug_table_bgcolor => '#ffffff'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 1
 ,p_plug_heading_bgcolor => '#ffffff'
 ,p_plug_font_size => '-1'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21496544900853444 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/navigation_region
prompt  ......region template 21496831637853444
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21496831637853444 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region navigation" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'||chr(10)||
''
 ,p_page_plug_template_name => 'Navigation Region'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 5
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21496831637853444 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/navigation_region_alternative_1
prompt  ......region template 21497145426853444
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21497145426853444 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region navigationalt1" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3 class="green">#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'||chr(10)||
''
 ,p_page_plug_template_name => 'Navigation Region, Alternative 1'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 16
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21497145426853444 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/region_without_buttons_and_title
prompt  ......region template 21497425540853444
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21497425540853444 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region wobuttonsandtitle" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Region without Buttons and Title'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 19
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21497425540853444 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/region_without_title
prompt  ......region template 21497716829853444
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21497716829853444 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region wotitle" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Region without Title'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 11
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21497716829853444 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/reports_region
prompt  ......region template 21498332864853444
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21498332864853444 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Reports Region'
 ,p_plug_table_bgcolor => '#ffffff'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 9
 ,p_plug_heading_bgcolor => '#ffffff'
 ,p_plug_font_size => '-1'
 ,p_template_comment => 'Red Theme'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21498332864853444 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/reports_region_100_width
prompt  ......region template 21498626363853446
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21498626363853446 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Reports Region 100% Width'
 ,p_plug_table_bgcolor => '#ffffff'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 13
 ,p_plug_heading_bgcolor => '#ffffff'
 ,p_plug_font_size => '-1'
 ,p_template_comment => 'Red Theme'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21498626363853446 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/reports_region_alternative_1
prompt  ......region template 21498927458853446
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21498927458853446 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region alternative" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3 class="green">#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'||chr(10)||
''||chr(10)||
''
 ,p_page_plug_template_name => 'Reports Region, Alternative 1'
 ,p_plug_table_bgcolor => '#ffffff'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 10
 ,p_plug_heading_bgcolor => '#ffffff'
 ,p_plug_font_size => '-1'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21498927458853446 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/sidebar_region
prompt  ......region template 21499227909853446
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21499227909853446 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region sidebar" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3>#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Sidebar Region'
 ,p_plug_table_bgcolor => '#f7f7e7'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 2
 ,p_plug_heading_bgcolor => '#f7f7e7'
 ,p_plug_font_size => '-1'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21499227909853446 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/sidebar_region_alternative_1
prompt  ......region template 21499546117853446
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21499546117853446 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="region sidebaralt1" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<h3 class="green">#TITLE#</h3>'||chr(10)||
'<div class="buttons">#CLOSE#&nbsp;&nbsp;#PREVIOUS##NEXT#&nbsp;#DELETE##EDIT##CHANGE##CREATE##CREATE2##EXPAND##COPY##HELP#</div>'||chr(10)||
'<div class="regionbody clear overflow"> #BODY# </div>'||chr(10)||
'</div>'
 ,p_page_plug_template_name => 'Sidebar Region, Alternative 1'
 ,p_plug_table_bgcolor => '#f7f7e7'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 3
 ,p_plug_heading_bgcolor => '#f7f7e7'
 ,p_plug_font_size => '-1'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21499546117853446 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/region/test_region
prompt  ......region template 21500130420853446
 
begin
 
wwv_flow_api.create_plug_template (
  p_id => 21500130420853446 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_template => 
'<div class="testregion" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>'||chr(10)||
'<span> #TITLE# </span> '||chr(10)||
'#BODY#'||chr(10)||
'</div>'||chr(10)||
''||chr(10)||
''
 ,p_page_plug_template_name => 'Test Region'
,p_theme_id => wwv_flow.g_flow_theme_id
 ,p_theme_class_id => 5
 ,p_translate_this_template => 'N'
  );
null;
 
end;
/

 
begin
 
declare
    t2 varchar2(32767) := null;
begin
t2 := null;
wwv_flow_api.set_plug_template_tab_attr (
  p_id=> 21500130420853446 + wwv_flow_api.g_id_offset,
  p_form_table_attr=> t2 );
exception when others then null;
end;
null;
 
end;
/

prompt  ...List Templates
--
--application/shared_components/user_interface/templates/list/hierarchical_expanding
prompt  ......list template 21504022535853460
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<li><img src="#IMAGE_PREFIX#themes/theme_509/node.gif" align="middle" alt="" />'||chr(10)||
'<a href="#LINK#">#TEXT#</a>'||chr(10)||
'</li>';

t2:=t2||'<li><img src="#IMAGE_PREFIX#themes/theme_509/node.gif" align="middle"  alt="" /><a href="#LINK#">#TEXT#</a></li>';

t3:=t3||'<li><img src="#IMAGE_PREFIX#themes/theme_509/node.gif" align="middle"  alt="" /><a href="#LINK#">#TEXT#</a></li>';

t4:=t4||'<li><img src="#IMAGE_PREFIX#themes/theme_509/node.gif"  align="middle" alt="" /><a href="#LINK#">#TEXT#</a></li>';

t5:=t5||'<li><img src="#IMAGE_PREFIX#themes/theme_509/plus.gif" align="middle" class="pseudoButtonInactive" /><a href="#LINK#" onclick="htmldb_ToggleWithImage(this,''#LIST_ITEM_ID#'')">#TEXT#</a></li>';

t6:=t6||'<li><img src="#IMAGE_PREFIX#themes/theme_509/plus.gif" align="middle"  onclick="htmldb_ToggleWithImage(this,''#LIST_ITEM_ID#'')" class="pseudoButtonInactive" /><a href="#LINK#">#TEXT#</a></li>';

t7:=t7||'<li><img src="#IMAGE_PREFIX#themes/theme_509/plus.gif" onclick="htmldb_ToggleWithImage(this,''#LIST_ITEM_ID#'')" align="middle" class="pseudoButtonInactive" /><a href="#LINK#">#TEXT#</a></li>';

t8:=t8||'<li><img src="#IMAGE_PREFIX#themes/theme_509/plus.gif" onclick="htmldb_ToggleWithImage(this,''#LIST_ITEM_ID#'')" align="middle" class="pseudoButtonInactive" /><a href="#LINK#">#TEXT#</a></li>';

wwv_flow_api.create_list_template (
  p_id=>21504022535853460 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Hierarchical Expanding',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 22,
  p_list_template_before_rows=>'<ul class="dhtmlTree">',
  p_list_template_after_rows=>'</ul><br style="clear:both;"/><br style="clear:both;"/>',
  p_before_sub_list=>'<ul id="#PARENT_LIST_ITEM_ID#" htmldb:listlevel="#LEVEL#" style="display:none;" class="dhtmlTree">',
  p_after_sub_list=>'</ul>',
  p_sub_list_item_current=> t3,
  p_sub_list_item_noncurrent=> t4,
  p_item_templ_curr_w_child=> t5,
  p_item_templ_noncurr_w_child=> t6,
  p_sub_templ_curr_w_child=> t7,
  p_sub_templ_noncurr_w_child=> t8,
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/horizontal_images_with_label_list
prompt  ......list template 21504337477853462
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<div class="current">'||chr(10)||
'<div class="image"><img src="#IMAGE_PREFIX##IMAGE#" border="0" #IMAGE_ATTR#/></div>'||chr(10)||
'#TEXT#'||chr(10)||
'</div>';

t2:=t2||'<div>'||chr(10)||
'<div class="image">'||chr(10)||
'<a href="#LINK#"><img src="#IMAGE_PREFIX##IMAGE#" border="0" #IMAGE_ATTR#/></a>'||chr(10)||
'</div>'||chr(10)||
'<a href="#LINK#">#TEXT#</a>'||chr(10)||
'</div>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>21504337477853462 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Horizontal Images with Label List',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 4,
  p_list_template_before_rows=>'<div class="HorizontalImageswithLabelList">',
  p_list_template_after_rows=>'</div>',
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/horizontal_links_list
prompt  ......list template 21504635287853462
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<a href="#LINK#" class="current">#TEXT#</a>';

t2:=t2||'<a href="#LINK#">#TEXT#</a>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>21504635287853462 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Horizontal Links List',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 3,
  p_list_template_before_rows=>'<div class="HorizontalLinksList">',
  p_list_template_after_rows=>'</div>',
  p_sub_list_item_current=> t3,
  p_sub_list_item_noncurrent=> t4,
  p_item_templ_curr_w_child=> t5,
  p_item_templ_noncurr_w_child=> t6,
  p_sub_templ_curr_w_child=> t7,
  p_sub_templ_noncurr_w_child=> t8,
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/tree_list
prompt  ......list template 21505841323853466
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<li><a href="#LINK#">#TEXT#</a></li>';

t2:=t2||'<li><a href="#LINK#">#TEXT#</a></li>';

t3:=t3||'<li><a href="#LINK#">#TEXT#</a></li>';

t4:=t4||'<li><a href="#LINK#">#TEXT#</a></li>';

t5:=t5||'<li><a href="#LINK#">#TEXT#</a></li>';

t6:=t6||'<li><a href="#LINK#">#TEXT#</a></li>';

t7:=t7||'<li><a href="#LINK#">#TEXT#</a></li>';

t8:=t8||'<li><a href="#LINK#">#TEXT#</a></li>';

wwv_flow_api.create_list_template (
  p_id=>21505841323853466 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Tree List',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 23,
  p_list_template_before_rows=>'<ul class="htmlTree">',
  p_list_template_after_rows=>'</ul><br style="clear:both;"/><br style="clear:both;"/>',
  p_before_sub_list=>'<ul id="#PARENT_LIST_ITEM_ID#" htmldb:listlevel="#LEVEL#">',
  p_after_sub_list=>'</ul>',
  p_sub_list_item_current=> t3,
  p_sub_list_item_noncurrent=> t4,
  p_item_templ_curr_w_child=> t5,
  p_item_templ_noncurr_w_child=> t6,
  p_sub_templ_curr_w_child=> t7,
  p_sub_templ_noncurr_w_child=> t8,
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/vertical_images_list
prompt  ......list template 21506139115853468
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<div class="image current">'||chr(10)||
'<a href="#LINK#"><img src="#IMAGE_PREFIX##IMAGE#" #IMAGE_ATTR# /></a> '||chr(10)||
'</div>'||chr(10)||
'<div class="label current">'||chr(10)||
'<a href="#LINK#">#TEXT#</a>'||chr(10)||
'</div>'||chr(10)||
'';

t2:=t2||'<div class="image">'||chr(10)||
'<a href="#LINK#"><img src="#IMAGE_PREFIX##IMAGE#" #IMAGE_ATTR# /></a> '||chr(10)||
'</div>'||chr(10)||
'<div class="label">'||chr(10)||
'<a href="#LINK#">#TEXT#</a>'||chr(10)||
'</div>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>21506139115853468 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Vertical Images List',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 5,
  p_list_template_before_rows=>'<div class="VerticalImagesList">',
  p_list_template_after_rows=>'</div>',
  p_between_items=>'<br />',
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/vertical_ordered_list
prompt  ......list template 21506725169853468
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<li class="current"><a href="#LINK#">#TEXT#</a></li>';

t2:=t2||'<li><a href="#LINK#">#TEXT#</a></li>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>21506725169853468 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Vertical Ordered List',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 2,
  p_list_template_before_rows=>'<ol class="VerticalOrderedList">',
  p_list_template_after_rows=>'</ol>',
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/vertical_sidebar_list
prompt  ......list template 21507022416853468
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<a href="#LINK#" class="current">#TEXT#</a>';

t2:=t2||'<a href="#LINK#">#TEXT#</a>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>21507022416853468 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Vertical Sidebar List',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 19,
  p_list_template_before_rows=>'<div class="VerticalSidebarList">',
  p_list_template_after_rows=>'</div>',
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/vertical_unordered_links_without_bullets
prompt  ......list template 21507318590853468
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<li class="current"><a href="#LINK#">#TEXT#</a></li>';

t2:=t2||'<li><a href="#LINK#">#TEXT#</a></li>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>21507318590853468 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Vertical Unordered Links without Bullets',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 18,
  p_list_template_before_rows=>'<ul class="VerticalUnorderedLinkswithoutBullets">',
  p_list_template_after_rows=>'</ul>',
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/vertical_unordered_list_with_bullets
prompt  ......list template 21507624090853471
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<li class="current"><a href="#LINK#">#TEXT#</a></li>';

t2:=t2||'<li><a href="#LINK#">#TEXT#</a></li>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>21507624090853471 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Vertical Unordered List with Bullets',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 1,
  p_list_template_before_rows=>'<ul class="VerticalUnorderedListwithBullets">',
  p_list_template_after_rows=>'</ul>',
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/wizard_progress_list
prompt  ......list template 21507917986853471
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<div class="current">#TEXT#</div>';

t2:=t2||'<div>#TEXT#</div>';

t3 := null;
t4 := null;
t5 := null;
t6 := null;
t7 := null;
t8 := null;
wwv_flow_api.create_list_template (
  p_id=>21507917986853471 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Wizard Progress List',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 17,
  p_list_template_before_rows=>'<div class="WizardProgressList">',
  p_list_template_after_rows=>'<center>&DONE.</center>'||chr(10)||
'</div>',
  p_translate_this_template => 'N',
  p_list_template_comment=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/list/hierarchical_expanded
prompt  ......list template 21589327592952552
 
begin
 
declare
  t varchar2(32767) := null;
  t2 varchar2(32767) := null;
  t3 varchar2(32767) := null;
  t4 varchar2(32767) := null;
  t5 varchar2(32767) := null;
  t6 varchar2(32767) := null;
  t7 varchar2(32767) := null;
  t8 varchar2(32767) := null;
  l_clob clob;
  l_clob2 clob;
  l_clob3 clob;
  l_clob4 clob;
  l_clob5 clob;
  l_clob6 clob;
  l_clob7 clob;
  l_clob8 clob;
  l_length number := 1;
begin
t:=t||'<li class="current"><a href="#LINK#" class="current">#TEXT#</a></li>';

t2:=t2||'<li><a href="#LINK#">#TEXT#</a></li>';

t3:=t3||'<li class="current"><a href="#LINK#" class="current">#TEXT#</a></li>';

t4:=t4||'<li><a href="#LINK#">#TEXT#</a></li>';

t5:=t5||'<li><a href="#LINK#" class="current">#TEXT#</a> <ul class="current"> ';

t6:=t6||'<li><a href="#LINK#">#TEXT#</a> <ul> ';

t7:=t7||'<li class="current"><a href="#LINK#" class="current">#TEXT#</a> <ul class="current"> ';

t8:=t8||'<li><a href="#LINK#">#TEXT#</a> <ul> ';

wwv_flow_api.create_list_template (
  p_id=>21589327592952552 + wwv_flow_api.g_id_offset,
  p_flow_id=>wwv_flow.g_flow_id,
  p_list_template_current=>t,
  p_list_template_noncurrent=> t2,
  p_list_template_name=>'Hierarchical Expanded',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 23,
  p_list_template_before_rows=>'<ul class="hierarchical-expanded">',
  p_list_template_after_rows=>'</ul>',
  p_after_sub_list=>'</ul></li> '||chr(10)||
'',
  p_sub_list_item_current=> t3,
  p_sub_list_item_noncurrent=> t4,
  p_item_templ_curr_w_child=> t5,
  p_item_templ_noncurr_w_child=> t6,
  p_sub_templ_curr_w_child=> t7,
  p_sub_templ_noncurr_w_child=> t8,
  p_list_template_comment=>'To make this work properly please put all children pages in parent node "Current List Entry" fields.');
end;
null;
 
end;
/

prompt  ...report templates
--
--application/shared_components/user_interface/templates/report/borderless
prompt  ......report template 21501023328853446
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  c4 varchar2(32767) := null;
begin
c1:=c1||'<td headers="#COLUMN_HEADER_NAME#" #ALIGNMENT# class="data">#COLUMN_VALUE#</td>';

c2 := null;
c3 := null;
c4 := null;
wwv_flow_api.create_row_template (
  p_id=> 21501023328853446 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_row_template_name=> 'Borderless',
  p_row_template1=> c1,
  p_row_template_condition1=> '',
  p_row_template2=> c2,
  p_row_template_condition2=> '',
  p_row_template3=> c3,
  p_row_template_condition3=> '',
  p_row_template4=> c4,
  p_row_template_condition4=> '',
  p_row_template_before_rows=>'<div class="ReportDiv" #REPORT_ATTRIBUTES# id="report_#REGION_STATIC_ID#">'||chr(10)||
'<table>#TOP_PAGINATION#</table>'||chr(10)||
'<table cellspacing="0" cellpadding="0" class="Borderless Report">',
  p_row_template_after_rows =>'<tr><td colspan="#COLCOUNT#">'||chr(10)||
'<div class="BottomBar"> '||chr(10)||
'<div class="CVS">#EXTERNAL_LINK##CSV_LINK#</div> <table class="PaginationTable">#PAGINATION#</table>'||chr(10)||
'</div></td></tr>'||chr(10)||
'</table>'||chr(10)||
'</div>',
  p_row_template_table_attr =>'OMIT',
  p_row_template_type =>'GENERIC_COLUMNS',
  p_column_heading_template=>'<th class="ReportHeader" #ALIGNMENT# id="#COLUMN_HEADER_NAME#">#COLUMN_HEADER#</th>',
  p_row_template_display_cond1=>'NOT_CONDITIONAL',
  p_row_template_display_cond2=>'NOT_CONDITIONAL',
  p_row_template_display_cond3=>'NOT_CONDITIONAL',
  p_row_template_display_cond4=>'NOT_CONDITIONAL',
  p_next_page_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT# &gt;</a>',
  p_previous_page_template=>'<a href="#LINK#" class="pagination">&lt;#PAGINATION_PREVIOUS#</a>',
  p_next_set_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT_SET#&gt;&gt;</a>',
  p_previous_set_template=>'<a href="#LINK#" class="pagination">&lt;&lt;#PAGINATION_PREVIOUS_SET#</a>',
  p_row_style_mouse_over=>'#EEE',
  p_row_style_checked=>'#EEE',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 1,
  p_row_template_comment=> '');
end;
null;
 
end;
/

 
begin
 
begin
wwv_flow_api.create_row_template_patch (
  p_id => 21501023328853446 + wwv_flow_api.g_id_offset,
  p_row_template_before_first =>'<tr #HIGHLIGHT_ROW#>',
  p_row_template_after_last =>'</tr>');
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/report/horizontal_border
prompt  ......report template 21501330925853452
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  c4 varchar2(32767) := null;
begin
c1:=c1||'<td headers="#COLUMN_HEADER_NAME#" #ALIGNMENT# class="data">#COLUMN_VALUE#</td>';

c2 := null;
c3 := null;
c4 := null;
wwv_flow_api.create_row_template (
  p_id=> 21501330925853452 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_row_template_name=> 'Horizontal Border',
  p_row_template1=> c1,
  p_row_template_condition1=> '',
  p_row_template2=> c2,
  p_row_template_condition2=> '',
  p_row_template3=> c3,
  p_row_template_condition3=> '',
  p_row_template4=> c4,
  p_row_template_condition4=> '',
  p_row_template_before_rows=>'<div class="ReportDiv" #REPORT_ATTRIBUTES# id="report_#REGION_STATIC_ID#">'||chr(10)||
'<table>#TOP_PAGINATION#</table>'||chr(10)||
'<table cellspacing="0" cellpadding="0" class="HorizontalBorder Report">',
  p_row_template_after_rows =>'<tr><td colspan="#COLCOUNT#">'||chr(10)||
'<div class="BottomBar"> '||chr(10)||
'<div class="CVS">#EXTERNAL_LINK##CSV_LINK#</div> <table class="PaginationTable">#PAGINATION#</table>'||chr(10)||
'</div></td></tr>'||chr(10)||
'</table>'||chr(10)||
'</div>',
  p_row_template_table_attr =>'OMIT',
  p_row_template_type =>'GENERIC_COLUMNS',
  p_column_heading_template=>'<th class="ReportHeader" #ALIGNMENT# id="#COLUMN_HEADER_NAME#">#COLUMN_HEADER#</th>',
  p_row_template_display_cond1=>'NOT_CONDITIONAL',
  p_row_template_display_cond2=>'NOT_CONDITIONAL',
  p_row_template_display_cond3=>'NOT_CONDITIONAL',
  p_row_template_display_cond4=>'NOT_CONDITIONAL',
  p_next_page_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT# &gt;</a>',
  p_previous_page_template=>'<a href="#LINK#" class="pagination">&lt;#PAGINATION_PREVIOUS#</a>',
  p_next_set_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT_SET#&gt;&gt;</a>',
  p_previous_set_template=>'<a href="#LINK#" class="pagination">&lt;&lt;#PAGINATION_PREVIOUS_SET#</a>',
  p_row_style_mouse_over=>'#EEE',
  p_row_style_checked=>'#EEE',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 2,
  p_row_template_comment=> '');
end;
null;
 
end;
/

 
begin
 
begin
wwv_flow_api.create_row_template_patch (
  p_id => 21501330925853452 + wwv_flow_api.g_id_offset,
  p_row_template_before_first =>'<tr #HIGHLIGHT_ROW#>',
  p_row_template_after_last =>'</tr>');
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/report/one_column_unordered_list
prompt  ......report template 21501614888853452
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  c4 varchar2(32767) := null;
begin
c1:=c1||'#COLUMN_VALUE#';

c2 := null;
c3 := null;
c4 := null;
wwv_flow_api.create_row_template (
  p_id=> 21501614888853452 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_row_template_name=> 'One Column Unordered List',
  p_row_template1=> c1,
  p_row_template_condition1=> '',
  p_row_template2=> c2,
  p_row_template_condition2=> '',
  p_row_template3=> c3,
  p_row_template_condition3=> '',
  p_row_template4=> c4,
  p_row_template_condition4=> '',
  p_row_template_before_rows=>'<div class="ReportDiv" #REPORT_ATTRIBUTES# id="report_#REGION_STATIC_ID#">'||chr(10)||
'<table>#TOP_PAGINATION#</table>'||chr(10)||
'<ul class="OneColumnUnorderedList">',
  p_row_template_after_rows =>'</ul><div class="CVS">#EXTERNAL_LINK##CSV_LINK#</div><table>#PAGINATION#</table></div>',
  p_row_template_table_attr =>'OMIT',
  p_row_template_type =>'GENERIC_COLUMNS',
  p_column_heading_template=>'',
  p_row_template_display_cond1=>'0',
  p_row_template_display_cond2=>'0',
  p_row_template_display_cond3=>'0',
  p_row_template_display_cond4=>'0',
  p_next_page_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT# &gt;</a>',
  p_previous_page_template=>'<a href="#LINK#" class="pagination">&lt;#PAGINATION_PREVIOUS#</a>',
  p_next_set_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT_SET#&gt;&gt;</a>',
  p_previous_set_template=>'<a href="#LINK#" class="pagination">&lt;&lt;#PAGINATION_PREVIOUS_SET#</a>',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 3,
  p_translate_this_template => 'N',
  p_row_template_comment=> '');
end;
null;
 
end;
/

 
begin
 
begin
wwv_flow_api.create_row_template_patch (
  p_id => 21501614888853452 + wwv_flow_api.g_id_offset,
  p_row_template_before_first =>'<li>',
  p_row_template_after_last =>'</li>');
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/report/standard_alternating_row_colors
prompt  ......report template 21502528575853454
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  c4 varchar2(32767) := null;
begin
c1:=c1||'<td headers="#COLUMN_HEADER_NAME#" #ALIGNMENT# class="data">#COLUMN_VALUE#</td>';

c2:=c2||'<td headers="#COLUMN_HEADER_NAME#" #ALIGNMENT# class="dataalt">#COLUMN_VALUE#</td>';

c3 := null;
c4 := null;
wwv_flow_api.create_row_template (
  p_id=> 21502528575853454 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_row_template_name=> 'Standard, Alternating Row Colors',
  p_row_template1=> c1,
  p_row_template_condition1=> '',
  p_row_template2=> c2,
  p_row_template_condition2=> '',
  p_row_template3=> c3,
  p_row_template_condition3=> '',
  p_row_template4=> c4,
  p_row_template_condition4=> '',
  p_row_template_before_rows=>'<div class="ReportDiv" #REPORT_ATTRIBUTES# id="report_#REGION_STATIC_ID#">'||chr(10)||
'<table>#TOP_PAGINATION#</table>'||chr(10)||
'<table cellspacing="0" cellpadding="0" class="StandardAlternatingRowColors Report">',
  p_row_template_after_rows =>'<tr><td colspan="#COLCOUNT#">'||chr(10)||
'<div class="BottomBar"> '||chr(10)||
'<div class="CVS">#EXTERNAL_LINK##CSV_LINK#</div> <table class="PaginationTable">#PAGINATION#</table>'||chr(10)||
'</div></td></tr>'||chr(10)||
'</table>'||chr(10)||
'</div>',
  p_row_template_table_attr =>'OMIT',
  p_row_template_type =>'GENERIC_COLUMNS',
  p_column_heading_template=>'<th class="ReportHeader" #ALIGNMENT# id="#COLUMN_HEADER_NAME#">#COLUMN_HEADER#</th>',
  p_row_template_display_cond1=>'ODD_ROW_NUMBERS',
  p_row_template_display_cond2=>'NOT_CONDITIONAL',
  p_row_template_display_cond3=>'NOT_CONDITIONAL',
  p_row_template_display_cond4=>'ODD_ROW_NUMBERS',
  p_next_page_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT# &gt;</a>',
  p_previous_page_template=>'<a href="#LINK#" class="pagination">&lt;#PAGINATION_PREVIOUS#</a>',
  p_next_set_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT_SET#&gt;&gt;</a>',
  p_previous_set_template=>'<a href="#LINK#" class="pagination">&lt;&lt;#PAGINATION_PREVIOUS_SET#</a>',
  p_row_style_mouse_over=>'#EEE',
  p_row_style_checked=>'#EEE',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 5,
  p_row_template_comment=> '');
end;
null;
 
end;
/

 
begin
 
begin
wwv_flow_api.create_row_template_patch (
  p_id => 21502528575853454 + wwv_flow_api.g_id_offset,
  p_row_template_before_first =>'<tr #HIGHLIGHT_ROW#>',
  p_row_template_after_last =>'</tr>');
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/report/value_attribute_pairs
prompt  ......report template 21503119925853457
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  c4 varchar2(32767) := null;
begin
c1:=c1||'<tr #HIGHLIGHT_ROW#>'||chr(10)||
'<td class="ReportHeader">#COLUMN_HEADER#</td>'||chr(10)||
'<td class="data">#COLUMN_VALUE#</td>'||chr(10)||
'</tr>';

c2 := null;
c3 := null;
c4 := null;
wwv_flow_api.create_row_template (
  p_id=> 21503119925853457 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_row_template_name=> 'Value Attribute Pairs',
  p_row_template1=> c1,
  p_row_template_condition1=> '',
  p_row_template2=> c2,
  p_row_template_condition2=> '',
  p_row_template3=> c3,
  p_row_template_condition3=> '',
  p_row_template4=> c4,
  p_row_template_condition4=> '',
  p_row_template_before_rows=>'<div class="ReportDiv" #REPORT_ATTRIBUTES# id="report_#REGION_STATIC_ID#">'||chr(10)||
'<table>#TOP_PAGINATION#</table>'||chr(10)||
'<table cellspacing="0" cellpadding="0" class="ValueAttributePairs Report">',
  p_row_template_after_rows =>'<tr> <td colspan="2"><div class="CVS">#EXTERNAL_LINK##CSV_LINK#</div>'||chr(10)||
'<table>#PAGINATION#</table></td></tr>'||chr(10)||
'</table>'||chr(10)||
'</div>',
  p_row_template_table_attr =>'OMIT',
  p_row_template_type =>'GENERIC_COLUMNS',
  p_column_heading_template=>'',
  p_row_template_display_cond1=>'0',
  p_row_template_display_cond2=>'0',
  p_row_template_display_cond3=>'0',
  p_row_template_display_cond4=>'0',
  p_next_page_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT# &gt;</a>',
  p_previous_page_template=>'<a href="#LINK#" class="pagination">&lt;#PAGINATION_PREVIOUS#</a>',
  p_next_set_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT_SET#&gt;&gt;</a>',
  p_previous_set_template=>'<a href="#LINK#" class="pagination">&lt;&lt;#PAGINATION_PREVIOUS_SET#</a>',
  p_row_style_mouse_over=>'#EEE',
  p_row_style_checked=>'#EEE',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 6,
  p_row_template_comment=> '');
end;
null;
 
end;
/

 
begin
 
begin
wwv_flow_api.create_row_template_patch (
  p_id => 21503119925853457 + wwv_flow_api.g_id_offset,
  p_row_template_before_first =>'',
  p_row_template_after_last =>'<tr><td class="seperate"></td><td class="seperate"></td></tr>');
exception when others then null;
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/report/standard
prompt  ......report template 21546732173990718
 
begin
 
declare
  c1 varchar2(32767) := null;
  c2 varchar2(32767) := null;
  c3 varchar2(32767) := null;
  c4 varchar2(32767) := null;
begin
c1:=c1||'<td headers="#COLUMN_HEADER_NAME#" #ALIGNMENT# class="data">#COLUMN_VALUE#</td>';

c2:=c2||'<td headers="#COLUMN_HEADER_NAME#" #ALIGNMENT# class="dataalt">#COLUMN_VALUE#</td>';

c3 := null;
c4 := null;
wwv_flow_api.create_row_template (
  p_id=> 21546732173990718 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_row_template_name=> 'Standard',
  p_row_template1=> c1,
  p_row_template_condition1=> '',
  p_row_template2=> c2,
  p_row_template_condition2=> '',
  p_row_template3=> c3,
  p_row_template_condition3=> '',
  p_row_template4=> c4,
  p_row_template_condition4=> '',
  p_row_template_before_rows=>'<div class="ReportDiv" #REPORT_ATTRIBUTES# id="report_#REGION_STATIC_ID#">'||chr(10)||
'<table>#TOP_PAGINATION#</table>'||chr(10)||
'<table class="Report">',
  p_row_template_after_rows =>'<tr><td colspan="#COLCOUNT#">'||chr(10)||
'<div class="BottomBar"> '||chr(10)||
'<div class="CVS">#EXTERNAL_LINK##CSV_LINK#</div> <table class="PaginationTable">#PAGINATION#</table>'||chr(10)||
'</div></td></tr>'||chr(10)||
'</table>'||chr(10)||
'</div>',
  p_row_template_table_attr =>'OMIT',
  p_row_template_type =>'GENERIC_COLUMNS',
  p_column_heading_template=>'<th class="ReportHeader" #ALIGNMENT# id="#COLUMN_HEADER_NAME#">#COLUMN_HEADER#</th>',
  p_row_template_display_cond1=>'ODD_ROW_NUMBERS',
  p_row_template_display_cond2=>'NOT_CONDITIONAL',
  p_row_template_display_cond3=>'NOT_CONDITIONAL',
  p_row_template_display_cond4=>'ODD_ROW_NUMBERS',
  p_next_page_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT# &gt;</a>',
  p_previous_page_template=>'<a href="#LINK#" class="pagination">&lt;#PAGINATION_PREVIOUS#</a>',
  p_next_set_template=>'<a href="#LINK#" class="pagination">#PAGINATION_NEXT_SET#&gt;&gt;</a>',
  p_previous_set_template=>'<a href="#LINK#" class="pagination">&lt;&lt;#PAGINATION_PREVIOUS_SET#</a>',
  p_row_style_mouse_over=>'#EEE',
  p_row_style_checked=>'#EEE',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 4,
  p_row_template_comment=> '');
end;
null;
 
end;
/

 
begin
 
begin
wwv_flow_api.create_row_template_patch (
  p_id => 21546732173990718 + wwv_flow_api.g_id_offset,
  p_row_template_before_first =>'<tr #HIGHLIGHT_ROW#>',
  p_row_template_after_last =>'</tr>');
exception when others then null;
end;
null;
 
end;
/

prompt  ...label templates
--
--application/shared_components/user_interface/templates/label/no_label
prompt  ......label template 21508237351853474
 
begin
 
begin
wwv_flow_api.create_field_template (
  p_id=> 21508237351853474 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_template_name=>'No Label',
  p_template_body1=>'<span class="nolabel">',
  p_template_body2=>'</span>',
  p_on_error_before_label=>'<div class="InlineError">',
  p_on_error_after_label=>'<br/>#ERROR_MESSAGE#</div>',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 13,
  p_template_comment=> '');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/label/optional_label
prompt  ......label template 21508325014853476
 
begin
 
begin
wwv_flow_api.create_field_template (
  p_id=> 21508325014853476 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_template_name=>'Optional Label',
  p_template_body1=>'<label for="#CURRENT_ITEM_NAME#" tabindex="999"><span class="label optionallabel ">',
  p_template_body2=>'</span></label>',
  p_on_error_before_label=>'<div class="inlineerror">',
  p_on_error_after_label=>'<br/>#ERROR_MESSAGE#</div>',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 3,
  p_template_comment=> '');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/label/optional_label_with_help
prompt  ......label template 21508438522853477
 
begin
 
begin
wwv_flow_api.create_field_template (
  p_id=> 21508438522853477 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_template_name=>'Optional Label with Help',
  p_template_body1=>'<label for="#CURRENT_ITEM_NAME#" tabindex="999">'||chr(10)||
'<a class="label optionallabelwhelp" href="javascript:popupFieldHelp(''#CURRENT_ITEM_ID#'',''&SESSION.'')" tabindex="999">',
  p_template_body2=>'</a></label>',
  p_on_error_before_label=>'<div class="inlineerror">',
  p_on_error_after_label=>'<br/>#ERROR_MESSAGE#</div>',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 1,
  p_template_comment=> '');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/label/required_label
prompt  ......label template 21508517532853477
 
begin
 
begin
wwv_flow_api.create_field_template (
  p_id=> 21508517532853477 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_template_name=>'Required Label',
  p_template_body1=>'<label for="#CURRENT_ITEM_NAME#" tabindex="999"><span class="label requiredlabel">',
  p_template_body2=>'</span></label>',
  p_on_error_before_label=>'<div class="inlineerror">',
  p_on_error_after_label=>'<br/>#ERROR_MESSAGE#</div>',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 4,
  p_template_comment=> '');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/label/required_label_with_help
prompt  ......label template 21508622265853477
 
begin
 
begin
wwv_flow_api.create_field_template (
  p_id=> 21508622265853477 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_template_name=>'Required Label with Help',
  p_template_body1=>'<label for="#CURRENT_ITEM_NAME#" tabindex="999">'||chr(10)||
'<a class="label requiredlabelwhelp" href="javascript:popupFieldHelp(''#CURRENT_ITEM_ID#'',''&SESSION.'')" tabindex="999">',
  p_template_body2=>'</a></label>',
  p_on_error_before_label=>'<div class="inlineerror">',
  p_on_error_after_label=>'<br/>#ERROR_MESSAGE#</div>',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 2,
  p_template_comment=> '');
end;
null;
 
end;
/

prompt  ...breadcrumb templates
--
--application/shared_components/user_interface/templates/breadcrumb/breadcrumb_menu
prompt  ......template 21509543064853479
 
begin
 
begin
wwv_flow_api.create_menu_template (
  p_id=> 21509543064853479 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_name=>'Breadcrumb Menu',
  p_before_first=>'',
  p_current_page_option=>'<a href="#LINK#" class="breadcrumb current">#NAME#</a>',
  p_non_current_page_option=>'<a href="#LINK#" class="breadcrumb">#NAME#</a>',
  p_menu_link_attributes=>'',
  p_between_levels=>'',
  p_after_last=>'',
  p_max_levels=>12,
  p_start_with_node=>'PARENT_TO_LEAF',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 1,
  p_template_comments=>'');
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/popuplov
prompt  ...popup list of values templates
--
prompt  ......template 21510027555853485
 
begin
 
begin
wwv_flow_api.create_popup_lov_template (
  p_id=> 21510027555853485 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_popup_icon=>'#IMAGE_PREFIX#list_gray.gif',
  p_popup_icon_attr=>'width="13" height="13" alt="Popup Lov"',
  p_popup_icon2=>'',
  p_popup_icon_attr2=>'',
  p_page_name=>'winlov',
  p_page_title=>'Search Dialog',
  p_page_html_head=>'<link rel="stylesheet" href="#IMAGE_PREFIX#themes/theme_509/style.css" type="text/css">'||chr(10)||
'',
  p_page_body_attr=>'onload="first_field()" style="background-color:#FFFFFF;margin:0;"',
  p_before_field_text=>'<div class="PopupHead">',
  p_page_heading_text=>'',
  p_page_footer_text =>'',
  p_filter_width     =>'20',
  p_filter_max_width =>'100',
  p_filter_text_attr =>'',
  p_find_button_text =>'Search',
  p_find_button_image=>'',
  p_find_button_attr =>'',
  p_close_button_text=>'Close',
  p_close_button_image=>'',
  p_close_button_attr=>'',
  p_next_button_text =>'Next >',
  p_next_button_image=>'',
  p_next_button_attr =>'',
  p_prev_button_text =>'< Previous',
  p_prev_button_image=>'',
  p_prev_button_attr =>'',
  p_after_field_text=>'</div>',
  p_scrollbars=>'1',
  p_resizable=>'1',
  p_width =>'400',
  p_height=>'450',
  p_result_row_x_of_y=>'<br /><div style="padding:2px; font-size:8pt;">Row(s) #FIRST_ROW# - #LAST_ROW#</div>',
  p_result_rows_per_pg=>500,
  p_before_result_set=>'<div class="PopupBody">',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 1,
  p_after_result_set   =>'</div>');
end;
null;
 
end;
/

prompt  ...calendar templates
--
--application/shared_components/user_interface/templates/calendar/calendar
prompt  ......template 21509725223853480
 
begin
 
begin
wwv_flow_api.create_calendar_template(
  p_id=> 21509725223853480 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_cal_template_name=>'Calendar',
  p_translate_this_template=> 'Y',
  p_day_of_week_format=> '<th class="DayOfWeek">#IDAY#</th>',
  p_month_title_format=> '<table cellspacing="0" cellpadding="0" summary="" class="MonthCalendarHolder"> '||chr(10)||
' <tr>'||chr(10)||
'   <td class="MonthTitle">#IMONTH# #YYYY#</td>'||chr(10)||
' </tr>'||chr(10)||
' <tr>'||chr(10)||
' <td class="MonthBody">',
  p_month_open_format=> '<table border="0" cellpadding="0" cellspacing="0" summary="0" class="Calendar">',
  p_month_close_format=> '</table></td>'||chr(10)||
'</tr>'||chr(10)||
'</table>'||chr(10)||
'',
  p_day_title_format=> '<div class="DayTitle">#DD#</div>',
  p_day_open_format=> '<td class="Day" valign="top">',
  p_day_close_format=> '</td>',
  p_today_open_format=> '<td valign="top" class="Today">',
  p_weekend_title_format=> '<div class="WeekendDayTitle">#DD#</div>',
  p_weekend_open_format => '<td valign="top" class="WeekendDay">',
  p_weekend_close_format => '</td>',
  p_nonday_title_format => '<div class="NonDayTitle">#DD#</div>',
  p_nonday_open_format => '<td class="NonDay" valign="top">',
  p_nonday_close_format => '</td>',
  p_week_title_format => '',
  p_week_open_format => '<tr>',
  p_week_close_format => '</tr> ',
  p_daily_title_format => '<th width="14%" class="calheader">#IDAY#</th>',
  p_daily_open_format => '<tr>',
  p_daily_close_format => '</tr>',
  p_weekly_title_format => '<table cellspacing="0" cellpadding="0" border="0" summary="" class="WeekCalendarHolder">'||chr(10)||
'<tr>'||chr(10)||
'<td class="MonthTitle" id="test">#WTITLE#</td>'||chr(10)||
'</tr>'||chr(10)||
'<tr>'||chr(10)||
'<td>',
  p_weekly_day_of_week_format => '<th class="DayOfWeek">#IDAY#<br>#MM#/#DD#</th>',
  p_weekly_month_open_format => '<table border="0" cellpadding="0" cellspacing="0" summary="0" class="WeekCalendar">',
  p_weekly_month_close_format => '</table></td></tr></table>',
  p_weekly_day_title_format => '',
  p_weekly_day_open_format => '<td class="Day" valign="top">',
  p_weekly_day_close_format => '<br /></td>',
  p_weekly_today_open_format => '<td class="Today" valign="top">',
  p_weekly_weekend_title_format => '',
  p_weekly_weekend_open_format => '<td valign="top" class="WeekendDay">',
  p_weekly_weekend_close_format => '<br /></td>',
  p_weekly_time_open_format => '<th class="Hour">',
  p_weekly_time_close_format => '<br /></th>',
  p_weekly_time_title_format => '#TIME#',
  p_weekly_hour_open_format => '<tr>',
  p_weekly_hour_close_format => '</tr>',
  p_daily_day_of_week_format => '<th class="DayOfWeek">#IDAY# #DD#/#MM#</th>',
  p_daily_month_title_format => '<table cellspacing="0" cellpadding="0" border="0" summary="" class="DayCalendarHolder"> <tr> <td class="MonthTitle">#IMONTH# #DD#, #YYYY#</td> </tr> <tr> <td>'||chr(10)||
'',
  p_daily_month_open_format => '<table border="0" cellpadding="2" cellspacing="0" summary="0" class="DayCalendar">',
  p_daily_month_close_format => '</table></td> </tr> </table>',
  p_daily_day_title_format => '',
  p_daily_day_open_format => '<td valign="top" class="Day">',
  p_daily_day_close_format => '<br /></td>',
  p_daily_today_open_format => '<td valign="top" class="Today">',
  p_daily_time_open_format => '<th class="Hour">',
  p_daily_time_close_format => '<br /></th>',
  p_daily_time_title_format => '#TIME#',
  p_daily_hour_open_format => '<tr>',
  p_daily_hour_close_format => '</tr>',
  p_cust_month_title_format => '',
  p_cust_day_of_week_format => '',
  p_cust_month_open_format => '',
  p_cust_month_close_format => '',
  p_cust_week_title_format => '',
  p_cust_week_open_format => '',
  p_cust_week_close_format => '',
  p_cust_day_title_format => '',
  p_cust_day_open_format => '',
  p_cust_day_close_format => '',
  p_cust_today_open_format => '',
  p_cust_daily_title_format => '',
  p_cust_daily_open_format => '',
  p_cust_daily_close_format => '',
  p_cust_nonday_title_format => '',
  p_cust_nonday_open_format => '',
  p_cust_nonday_close_format => '',
  p_cust_weekend_title_format => '',
  p_cust_weekend_open_format => '',
  p_cust_weekend_close_format => '',
  p_cust_hour_open_format => '',
  p_cust_hour_close_format => '',
  p_cust_time_title_format => '',
  p_cust_time_open_format => '',
  p_cust_time_close_format => '',
  p_cust_wk_month_title_format => '',
  p_cust_wk_day_of_week_format => '',
  p_cust_wk_month_open_format => '',
  p_cust_wk_month_close_format => '',
  p_cust_wk_week_title_format => '',
  p_cust_wk_week_open_format => '',
  p_cust_wk_week_close_format => '',
  p_cust_wk_day_title_format => '',
  p_cust_wk_day_open_format => '',
  p_cust_wk_day_close_format => '',
  p_cust_wk_today_open_format => '',
  p_cust_wk_weekend_title_format => '',
  p_cust_wk_weekend_open_format => '',
  p_cust_wk_weekend_close_format => '',
  p_cust_month_day_height_pix => '',
  p_cust_month_day_height_per => '',
  p_cust_week_day_width_pix => '',
  p_cust_week_day_width_per => '',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 1,
  p_reference_id=> null);
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/calendar/calendar_alternative_1
prompt  ......template 21509814549853483
 
begin
 
begin
wwv_flow_api.create_calendar_template(
  p_id=> 21509814549853483 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_cal_template_name=>'Calendar, Alternative 1',
  p_translate_this_template=> 'Y',
  p_day_of_week_format=> '<th class="DayOfWeek">#IDAY#</th>',
  p_month_title_format=> '<table cellspacing="0" cellpadding="0" border="0" summary="" class="CalendarAlternativeHolder"> '||chr(10)||
' <tr>'||chr(10)||
'   <td class="MonthTitle">#IMONTH# #YYYY#</td>'||chr(10)||
' </tr>'||chr(10)||
' <tr>'||chr(10)||
' <td class="t502MonthBody">',
  p_month_open_format=> '<table border="0" cellpadding="0" cellspacing="0" summary="0" class="CalendarAlternative">',
  p_month_close_format=> '</table></td>'||chr(10)||
'</tr>'||chr(10)||
'</table>'||chr(10)||
'',
  p_day_title_format=> '<div class="DayTitle">#DD#</div>',
  p_day_open_format=> '<td class="Day" valign="top">',
  p_day_close_format=> '</td>',
  p_today_open_format=> '<td valign="top" class="Today">',
  p_weekend_title_format=> '<div class="WeekendDayTitle">#DD#</div>',
  p_weekend_open_format => '<td valign="top" class="WeekendDay">',
  p_weekend_close_format => '</td>',
  p_nonday_title_format => '<div class="NonDayTitle">#DD#</div>',
  p_nonday_open_format => '<td class="NonDay" valign="top">',
  p_nonday_close_format => '</td>',
  p_week_title_format => '',
  p_week_open_format => '<tr>',
  p_week_close_format => '</tr> ',
  p_daily_title_format => '<th width="14%" class="calheader">#IDAY#</th>',
  p_daily_open_format => '<tr>',
  p_daily_close_format => '</tr>',
  p_weekly_title_format => '<table cellspacing="0" cellpadding="0" border="0" summary="" class="WeekCalendarAlternativeHolder">'||chr(10)||
'<tr>'||chr(10)||
'<td class="MonthTitle" id="test">#WTITLE#</td>'||chr(10)||
'</tr>'||chr(10)||
'<tr>'||chr(10)||
'<td>',
  p_weekly_day_of_week_format => '<th class="DayOfWeek">#IDAY#<br>#MM#/#DD#</th>',
  p_weekly_month_open_format => '<table border="0" cellpadding="0" cellspacing="0" summary="0" class="WeekCalendarAlternative">',
  p_weekly_month_close_format => '</table></td></tr></table>',
  p_weekly_day_title_format => '',
  p_weekly_day_open_format => '<td class="Day" valign="top">',
  p_weekly_day_close_format => '<br /></td>',
  p_weekly_today_open_format => '<td class="Today" valign="top">',
  p_weekly_weekend_title_format => '',
  p_weekly_weekend_open_format => '<td valign="top" class="NonDay">',
  p_weekly_weekend_close_format => '<br /></td>',
  p_weekly_time_open_format => '<th class="Hour">',
  p_weekly_time_close_format => '<br /></th>',
  p_weekly_time_title_format => '#TIME#',
  p_weekly_hour_open_format => '<tr>',
  p_weekly_hour_close_format => '</tr>',
  p_daily_day_of_week_format => '<th class="DayOfWeek">#IDAY# #DD#/#MM#</th>',
  p_daily_month_title_format => '<table cellspacing="0" cellpadding="0" border="0" summary="" class="DayCalendarAlternativeHolder"> <tr><td class="MonthTitle">#IMONTH# #DD#, #YYYY#</td></tr><tr><td>'||chr(10)||
'',
  p_daily_month_open_format => '<table border="0" cellpadding="2" cellspacing="0" summary="0" class="DayCalendarAlternative">',
  p_daily_month_close_format => '</table></td> </tr> </table>',
  p_daily_day_title_format => '',
  p_daily_day_open_format => '<td valign="top" class="Day">',
  p_daily_day_close_format => '<br /></td>',
  p_daily_today_open_format => '<td valign="top" class="Today">',
  p_daily_time_open_format => '<th class="Hour">',
  p_daily_time_close_format => '<br /></th>',
  p_daily_time_title_format => '#TIME#',
  p_daily_hour_open_format => '<tr>',
  p_daily_hour_close_format => '</tr>',
  p_cust_month_title_format => '',
  p_cust_day_of_week_format => '',
  p_cust_month_open_format => '',
  p_cust_month_close_format => '',
  p_cust_week_title_format => '',
  p_cust_week_open_format => '',
  p_cust_week_close_format => '',
  p_cust_day_title_format => '',
  p_cust_day_open_format => '',
  p_cust_day_close_format => '',
  p_cust_today_open_format => '',
  p_cust_daily_title_format => '',
  p_cust_daily_open_format => '',
  p_cust_daily_close_format => '',
  p_cust_nonday_title_format => '',
  p_cust_nonday_open_format => '',
  p_cust_nonday_close_format => '',
  p_cust_weekend_title_format => '',
  p_cust_weekend_open_format => '',
  p_cust_weekend_close_format => '',
  p_cust_hour_open_format => '',
  p_cust_hour_close_format => '',
  p_cust_time_title_format => '',
  p_cust_time_open_format => '',
  p_cust_time_close_format => '',
  p_cust_wk_month_title_format => '',
  p_cust_wk_day_of_week_format => '',
  p_cust_wk_month_open_format => '',
  p_cust_wk_month_close_format => '',
  p_cust_wk_week_title_format => '',
  p_cust_wk_week_open_format => '',
  p_cust_wk_week_close_format => '',
  p_cust_wk_day_title_format => '',
  p_cust_wk_day_open_format => '',
  p_cust_wk_day_close_format => '',
  p_cust_wk_today_open_format => '',
  p_cust_wk_weekend_title_format => '',
  p_cust_wk_weekend_open_format => '',
  p_cust_wk_weekend_close_format => '',
  p_cust_month_day_height_pix => '',
  p_cust_month_day_height_per => '',
  p_cust_week_day_width_pix => '',
  p_cust_week_day_width_per => '',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 2,
  p_reference_id=> null);
end;
null;
 
end;
/

--application/shared_components/user_interface/templates/calendar/small_calendar
prompt  ......template 21509940931853483
 
begin
 
begin
wwv_flow_api.create_calendar_template(
  p_id=> 21509940931853483 + wwv_flow_api.g_id_offset,
  p_flow_id=> wwv_flow.g_flow_id,
  p_cal_template_name=>'Small Calendar',
  p_translate_this_template=> 'Y',
  p_day_of_week_format=> '',
  p_month_title_format=> '<table cellspacing="0" cellpadding="0" border="0" summary="" class="SmallCalendarHolder"> '||chr(10)||
' <tr>'||chr(10)||
'   <td class="MonthTitle">#IMONTH# #YYYY#</td>'||chr(10)||
' </tr>'||chr(10)||
' <tr>'||chr(10)||
' <td class="MonthBody">',
  p_month_open_format=> '<table border="0" cellpadding="0" cellspacing="0" summary="0" class="SmallCalendar">',
  p_month_close_format=> '</table></td>'||chr(10)||
'</tr>'||chr(10)||
'</table>'||chr(10)||
'',
  p_day_title_format=> '<div class="DayTitle">#DD#</div>',
  p_day_open_format=> '<td class="Day" valign="top">',
  p_day_close_format=> '</td>',
  p_today_open_format=> '<td valign="top" class="Today">',
  p_weekend_title_format=> '<div class="WeekendDayTitle">#DD#</div>',
  p_weekend_open_format => '<td valign="top" class="WeekendDay">',
  p_weekend_close_format => '</td>',
  p_nonday_title_format => '<div class="NonDayTitle">#DD#</div>',
  p_nonday_open_format => '<td class="NonDay" valign="top">',
  p_nonday_close_format => '</td>',
  p_week_title_format => '',
  p_week_open_format => '<tr>',
  p_week_close_format => '</tr> ',
  p_daily_title_format => '<th width="14%" class="calheader">#IDAY#</th>',
  p_daily_open_format => '<tr>',
  p_daily_close_format => '</tr>',
  p_weekly_title_format => '<table cellspacing="0" cellpadding="0" border="0" summary="" class="SmallWeekCalendarHolder">'||chr(10)||
'<tr>'||chr(10)||
'<td class="MonthTitle" id="test">#WTITLE#</td>'||chr(10)||
'</tr>'||chr(10)||
'<tr>'||chr(10)||
'<td>',
  p_weekly_day_of_week_format => '<th class="DayOfWeek">#IDY# #DD#</th>',
  p_weekly_month_open_format => '<table border="0" cellpadding="0" cellspacing="0" summary="0" class="SmallWeekCalendar">',
  p_weekly_month_close_format => '</table></td></tr></table>',
  p_weekly_day_title_format => '',
  p_weekly_day_open_format => '<td class="Day" valign="top">',
  p_weekly_day_close_format => '<br /></td>',
  p_weekly_today_open_format => '<td class="Today" valign="top">',
  p_weekly_weekend_title_format => '',
  p_weekly_weekend_open_format => '<td valign="top" class="WeekendDay">',
  p_weekly_weekend_close_format => '<br /></td>',
  p_weekly_time_open_format => '<th class="Hour">',
  p_weekly_time_close_format => '<br /></th>',
  p_weekly_time_title_format => '#TIME#',
  p_weekly_hour_open_format => '<tr>',
  p_weekly_hour_close_format => '</tr>',
  p_daily_day_of_week_format => '<th class="DayOfWeek">#IDAY#</th>',
  p_daily_month_title_format => '<table cellspacing="0" cellpadding="0" border="0" summary="" class="SmallDayCalendarHolder"> <tr> <td class="MonthTitle">#IMONTH# #DD#, #YYYY#</td> </tr><tr><td>'||chr(10)||
'',
  p_daily_month_open_format => '<table border="0" cellpadding="2" cellspacing="0" summary="0" class="SmallDayCalendar">',
  p_daily_month_close_format => '</table></td></tr></table>',
  p_daily_day_title_format => '',
  p_daily_day_open_format => '<td valign="top" class="Day">',
  p_daily_day_close_format => '<br /></td>',
  p_daily_today_open_format => '<td valign="top" class="Today">',
  p_daily_time_open_format => '<th class="Hour">',
  p_daily_time_close_format => '<br /></th>',
  p_daily_time_title_format => '#TIME#',
  p_daily_hour_open_format => '<tr>',
  p_daily_hour_close_format => '</tr>',
  p_cust_month_title_format => '',
  p_cust_day_of_week_format => '',
  p_cust_month_open_format => '',
  p_cust_month_close_format => '',
  p_cust_week_title_format => '',
  p_cust_week_open_format => '',
  p_cust_week_close_format => '',
  p_cust_day_title_format => '',
  p_cust_day_open_format => '',
  p_cust_day_close_format => '',
  p_cust_today_open_format => '',
  p_cust_daily_title_format => '',
  p_cust_daily_open_format => '',
  p_cust_daily_close_format => '',
  p_cust_nonday_title_format => '',
  p_cust_nonday_open_format => '',
  p_cust_nonday_close_format => '',
  p_cust_weekend_title_format => '',
  p_cust_weekend_open_format => '',
  p_cust_weekend_close_format => '',
  p_cust_hour_open_format => '',
  p_cust_hour_close_format => '',
  p_cust_time_title_format => '',
  p_cust_time_open_format => '',
  p_cust_time_close_format => '',
  p_cust_wk_month_title_format => '',
  p_cust_wk_day_of_week_format => '',
  p_cust_wk_month_open_format => '',
  p_cust_wk_month_close_format => '',
  p_cust_wk_week_title_format => '',
  p_cust_wk_week_open_format => '',
  p_cust_wk_week_close_format => '',
  p_cust_wk_day_title_format => '',
  p_cust_wk_day_open_format => '',
  p_cust_wk_day_close_format => '',
  p_cust_wk_today_open_format => '',
  p_cust_wk_weekend_title_format => '',
  p_cust_wk_weekend_open_format => '',
  p_cust_wk_weekend_close_format => '',
  p_cust_month_day_height_pix => '',
  p_cust_month_day_height_per => '',
  p_cust_week_day_width_pix => '',
  p_cust_week_day_width_per => '',
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_class_id => 3,
  p_reference_id=> null);
end;
null;
 
end;
/

prompt  ...application themes
--
--application/shared_components/user_interface/themes/fresh_ash_apex_designers_com
prompt  ......theme 21510225752853490
begin
wwv_flow_api.create_theme (
  p_id =>21510225752853490 + wwv_flow_api.g_id_offset,
  p_flow_id =>wwv_flow.g_flow_id,
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_theme_name=>'Fresh & Ash APEX-Designers.com',
  p_default_page_template=>21492329643853433 + wwv_flow_api.g_id_offset,
  p_error_template=>21492021879853433 + wwv_flow_api.g_id_offset,
  p_printer_friendly_template=>21493227602853435 + wwv_flow_api.g_id_offset,
  p_breadcrumb_display_point=>'REGION_POSITION_01',
  p_sidebar_display_point=>'REGION_POSITION_02',
  p_login_template=>21491530007853426 + wwv_flow_api.g_id_offset,
  p_default_button_template=>21508739389853477 + wwv_flow_api.g_id_offset,
  p_default_region_template=>21498332864853444 + wwv_flow_api.g_id_offset,
  p_default_chart_template =>21495919065853443 + wwv_flow_api.g_id_offset,
  p_default_form_template  =>21496218029853444 + wwv_flow_api.g_id_offset,
  p_default_reportr_template   =>21498332864853444 + wwv_flow_api.g_id_offset,
  p_default_tabform_template=>21498332864853444 + wwv_flow_api.g_id_offset,
  p_default_wizard_template=>21500436050853446 + wwv_flow_api.g_id_offset,
  p_default_menur_template=>21494745374853443 + wwv_flow_api.g_id_offset,
  p_default_listr_template=>21498332864853444 + wwv_flow_api.g_id_offset,
  p_default_irr_template=>null + wwv_flow_api.g_id_offset,
  p_default_report_template   =>21546732173990718 + wwv_flow_api.g_id_offset,
  p_default_label_template=>21508438522853477 + wwv_flow_api.g_id_offset,
  p_default_menu_template=>21509543064853479 + wwv_flow_api.g_id_offset,
  p_default_calendar_template=>21509725223853480 + wwv_flow_api.g_id_offset,
  p_default_list_template=>21507624090853471 + wwv_flow_api.g_id_offset,
  p_default_option_label=>21508438522853477 + wwv_flow_api.g_id_offset,
  p_theme_description=>'This is free theme from APEX-Designers.com'||chr(10)||
'Enjoy !'||chr(10)||
'For any assistance or bug report please go to APEX-Designers.com',
  p_default_required_label=>21508622265853477 + wwv_flow_api.g_id_offset);
end;
/
 
begin
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000096000000500806000000FBB08C4B000000097048597300000B1300000B1301009A9C1800000A4F6943435050686F746F73686F70204943432070726F66696C65000078DA9D53675453E9163DF7DEF4424B';
wwv_flow_api.g_varchar2_table(2) := '8880944B6F5215082052428B801491262A2109104A8821A1D91551C1114545041BC8A088038E8E808C15512C0C8A0AD807E421A28E83A3888ACAFBE17BA36BD6BCF7E6CDFEB5D73EE7ACF39DB3CF07C0080C9648335135800CA9421E11E083C7C4C6E1E4';
wwv_flow_api.g_varchar2_table(3) := '2E40810A2470001008B3642173FD230100F87E3C3C2B22C007BE000178D30B0800C04D9BC0301C87FF0FEA42995C01808401C07491384B08801400407A8E42A600404601809D98265300A0040060CB6362E300502D0060277FE6D300809DF8997B01005B';
wwv_flow_api.g_varchar2_table(4) := '94211501A09100201365884400683B00ACCF568A450058300014664BC43900D82D00304957664800B0B700C0CE100BB200080C00305188852900047B0060C8232378008499001446F2573CF12BAE10E72A00007899B23CB9243945815B082D710757572E';
wwv_flow_api.g_varchar2_table(5) := '1E28CE49172B14366102619A402EC27999193281340FE0F3CC0000A0911511E083F3FD78CE0EAECECE368EB60E5F2DEABF06FF226262E3FEE5CFAB70400000E1747ED1FE2C2FB31A803B06806DFEA225EE04685E0BA075F78B66B20F40B500A0E9DA57F3';
wwv_flow_api.g_varchar2_table(6) := '70F87E3C3C45A190B9D9D9E5E4E4D84AC4425B61CA577DFE67C25FC057FD6CF97E3CFCF7F5E0BEE22481325D814704F8E0C2CCF44CA51CCF92098462DCE68F47FCB70BFFFC1DD322C44962B9582A14E35112718E449A8CF332A52289429229C525D2FF64';
wwv_flow_api.g_varchar2_table(7) := 'E2DF2CFB033EDF3500B06A3E017B912DA85D6303F64B27105874C0E2F70000F2BB6FC1D4280803806883E1CF77FFEF3FFD47A02500806649927100005E44242E54CAB33FC708000044A0812AB0411BF4C1182CC0061CC105DCC10BFC6036844224C4C242';
wwv_flow_api.g_varchar2_table(8) := '10420A64801C726029AC82422886CDB01D2A602FD4401D34C051688693700E2EC255B80E3D700FFA61089EC128BC81090441C808136121DA8801628A58238E08179985F821C14804128B2420C9881451224B91354831528A542055481DF23D720239875C';
wwv_flow_api.g_varchar2_table(9) := '46BA913BC8003282FC86BC47319481B2513DD40CB543B9A8371A8446A20BD06474319A8F16A09BD072B41A3D8C36A1E7D0AB680FDA8F3E43C730C0E8180733C46C302EC6C342B1382C099363CBB122AC0CABC61AB056AC03BB89F563CFB17704128145C0';
wwv_flow_api.g_varchar2_table(10) := '093604774220611E4148584C584ED848A8201C243411DA093709038451C2272293A84BB426BA11F9C4186232318758482C23D6128F132F107B8843C437241289433227B9900249B1A454D212D246D26E5223E92CA99B34481A2393C9DA646BB20739942C';
wwv_flow_api.g_varchar2_table(11) := '202BC885E49DE4C3E433E41BE421F25B0A9D624071A4F853E22852CA6A4A19E510E534E5066598324155A39A52DDA8A15411358F5A42ADA1B652AF5187A81334759A39CD8316494BA5ADA295D31A681768F769AFE874BA11DD951E4E97D057D2CBE947E8';
wwv_flow_api.g_varchar2_table(12) := '97E803F4770C0D861583C7886728199B18071867197718AF984CA619D38B19C754303731EB98E7990F996F55582AB62A7C1591CA0A954A9526951B2A2F54A9AAA6AADEAA0B55F355CB548FA95E537DAE46553353E3A909D496AB55AA9D50EB531B5367A9';
wwv_flow_api.g_varchar2_table(13) := '3BA887AA67A86F543FA47E59FD890659C34CC34F43A451A0B15FE3BCC6200B6319B3782C216B0DAB86758135C426B1CDD97C762ABB98FD1DBB8B3DAAA9A13943334A3357B352F394663F07E39871F89C744E09E728A797F37E8ADE14EF29E2291BA6344C';
wwv_flow_api.g_varchar2_table(14) := 'B931655C6BAA96979658AB48AB51AB47EBBD36AEEDA79DA6BD45BB59FB810E41C74A275C2747678FCE059DE753D953DDA70AA7164D3D3AF5AE2EAA6BA51BA1BB4477BF6EA7EE989EBE5E809E4C6FA7DE79BDE7FA1C7D2FFD54FD6DFAA7F5470C5806B30C';
wwv_flow_api.g_varchar2_table(15) := '2406DB0CCE183CC535716F3C1D2FC7DBF151435DC34043A561956197E18491B9D13CA3D5468D460F8C69C65CE324E36DC66DC6A326062621264B4DEA4DEE9A524DB9A629A63B4C3B4CC7CDCCCDA2CDD699359B3D31D732E79BE79BD79BDFB7605A785A2C';
wwv_flow_api.g_varchar2_table(16) := 'B6A8B6B86549B2E45AA659EEB6BC6E855A3959A558555A5DB346AD9DAD25D6BBADBBA711A7B94E934EAB9ED667C3B0F1B6C9B6A9B719B0E5D806DBAEB66DB67D6167621767B7C5AEC3EE93BD937DBA7D8DFD3D070D87D90EAB1D5A1D7E73B472143A563A';
wwv_flow_api.g_varchar2_table(17) := 'DE9ACE9CEE3F7DC5F496E92F6758CF10CFD833E3B613CB29C4699D539BD347671767B97383F3888B894B82CB2E973E2E9B1BC6DDC8BDE44A74F5715DE17AD2F59D9BB39BC2EDA8DBAFEE36EE69EE87DC9FCC349F299E593373D0C3C843E051E5D13F0B9F';
wwv_flow_api.g_varchar2_table(18) := '95306BDFAC7E4F434F8167B5E7232F632F9157ADD7B0B7A577AAF761EF173EF63E729FE33EE33C37DE32DE595FCC37C0B7C8B7CB4FC36F9E5F85DF437F23FF64FF7AFFD100A78025016703898141815B02FBF87A7C21BF8E3F3ADB65F6B2D9ED418CA0B9';
wwv_flow_api.g_varchar2_table(19) := '4115418F82AD82E5C1AD2168C8EC90AD21F7E798CE91CE690E85507EE8D6D00761E6618BC37E0C2785878557863F8E7088581AD131973577D1DC4373DF44FA449644DE9B67314F39AF2D4A352A3EAA2E6A3CDA37BA34BA3FC62E6659CCD5589D58496C4B';
wwv_flow_api.g_varchar2_table(20) := '1C392E2AAE366E6CBEDFFCEDF387E29DE20BE37B17982FC85D7079A1CEC2F485A716A92E122C3A96404C884E3894F041102AA8168C25F21377258E0A79C21DC267222FD136D188D8435C2A1E4EF2482A4D7A92EC91BC357924C533A52CE5B98427A990BC';
wwv_flow_api.g_varchar2_table(21) := '4C0D4CDD9B3A9E169A76206D323D3ABD31839291907142AA214D93B667EA67E66676CBAC6585B2FEC56E8BB72F1E9507C96BB390AC05592D0AB642A6E8545A28D72A07B267655766BFCD89CA3996AB9E2BCDEDCCB3CADB90379CEF9FFFED12C212E192B6';
wwv_flow_api.g_varchar2_table(22) := 'A5864B572D1D58E6BDAC6A39B23C7179DB0AE315052B865606AC3CB88AB62A6DD54FABED5797AE7EBD267A4D6B815EC1CA82C1B5016BEB0B550AE5857DEBDCD7ED5D4F582F59DFB561FA869D1B3E15898AAE14DB1797157FD828DC78E51B876FCABF99DC';
wwv_flow_api.g_varchar2_table(23) := '94B4A9ABC4B964CF66D266E9E6DE2D9E5B0E96AA97E6970E6E0DD9DAB40DDF56B4EDF5F645DB2F97CD28DBBB83B643B9A3BF3CB8BC65A7C9CECD3B3F54A454F454FA5436EED2DDB561D7F86ED1EE1B7BBCF634ECD5DB5BBCF7FD3EC9BEDB5501554DD566';
wwv_flow_api.g_varchar2_table(24) := 'D565FB49FBB3F73FAE89AAE9F896FB6D5DAD4E6D71EDC703D203FD07230EB6D7B9D4D51DD23D54528FD62BEB470EC71FBEFE9DEF772D0D360D558D9CC6E223704479E4E9F709DFF71E0D3ADA768C7BACE107D31F761D671D2F6A429AF29A469B539AFB5B';
wwv_flow_api.g_varchar2_table(25) := '625BBA4FCC3ED1D6EADE7AFC47DB1F0F9C343C59794AF354C969DAE982D39367F2CF8C9D959D7D7E2EF9DC60DBA2B67BE763CEDF6A0F6FEFBA1074E1D245FF8BE73BBC3BCE5CF2B874F2B2DBE51357B8579AAF3A5F6DEA74EA3CFE93D34FC7BB9CBB9AAE';
wwv_flow_api.g_varchar2_table(26) := 'B95C6BB9EE7ABDB57B66F7E91B9E37CEDDF4BD79F116FFD6D59E393DDDBDF37A6FF7C5F7F5DF16DD7E7227FDCECBBBD97727EEADBC4FBC5FF440ED41D943DD87D53F5BFEDCD8EFDC7F6AC077A0F3D1DC47F7068583CFFE91F58F0F43058F998FCB860D86';
wwv_flow_api.g_varchar2_table(27) := 'EB9E383E3939E23F72FDE9FCA743CF64CF269E17FEA2FECBAE17162F7EF8D5EBD7CED198D1A197F29793BF6D7CA5FDEAC0EB19AFDBC6C2C61EBEC97833315EF456FBEDC177DC771DEFA3DF0F4FE47C207F28FF68F9B1F553D0A7FB93199393FF040398F3';
wwv_flow_api.g_varchar2_table(28) := 'FC63332DDB000000206348524D00007A25000080830000F9FF000080E9000075300000EA6000003A980000176F925FC546000018734944415478DAEC5D7B7053D979FFE969E9DAB2643DB02D6C1983590BF358743190DD35796C97C74CD2C5CB645BD63B';
wwv_flow_api.g_varchar2_table(29) := '9D6E59327994D0994E7697CCB46993690742DB9976BB4D3B0D61BBC940484362C30C0D06363B09669300962198B578D996FCB664D9B2ACAB9775D53F245DEBEA5E4957B6C423E89BB963EBEADCEF9CEF9CDFF97DDFF9CEBD57A268348AA21425DF222E76';
wwv_flow_api.g_varchar2_table(30) := '41518AC02A4A11584579BA459AEB0516929403D80EE065009B009401682C76E51F8C4400DC00E0077011407B8FD57A2BD305CDCDCDB87EFD3AEB9C4868F06E21C932006F01F8EB38988AF21488441C736A119A7EB5C76A3D2DF43A41C0B290E42B008E01';
wwv_flow_api.g_varchar2_table(31) := 'D0FEA175585104D2184D03C06F00ECEDB15A1D4B06968524BF0DE05B45C014250E2E37803D3D56EBAF160D2C0B49FE2B80BF2A02A72829E00A01D891095C69816521C937E3EEAF089CA2A4020B009C00B6F658AD0382578516926C00F0BD870518854201';
wwv_flow_api.g_varchar2_table(32) := '71CAF7344D2310081447F2F11503801F02D82698B12C24F953005F2C04D388C56268341A100401822020914832960F87C3080402A0280A5EAF17E170B838A48F0763258477B5C8019685243701B89E6FD72493C9603018A056AB97A4C7E3F1C0E974E604';
wwv_flow_api.g_varchar2_table(33) := 'B0963FA5A0AF8DE45C97EDE312D83E963FB12068FD869773AEEB27045C43927C82EB4E8FD56A16E20ADFC8779CA352A9505D5D9D959D84885AAD46595919C6C6C6E0F57A055DA3AD9947D5EAF99CEB1ABE237DA2D9A56A3577F2C9953480A58D83442C4E';
wwv_flow_api.g_varchar2_table(34) := '0657A385243F931AC8F321E8E57C1AA756AB51535393175031864924A8A9A911CC7ED12840D3D19C8F27FDCE0F3E9B0A1433EFCAC85816925C0EC094AFCA6532192A2B2B0BD671959595A0282AAB5BA4699A2F361000C8271B587C36E7D3A424E67A2E9B';
wwv_flow_api.g_varchar2_table(35) := '2B6C4834281FEE305FEE2F1373555757C3E170649FB9116E8FDEBFAAC0DC54FAF68DDD973DD98CC5637314F99D2C717035650356DEB66C140A054A4B4B05950D87C3703A9DF07ABDA0691A32990C1A8D061515155981595A5A0A994C9691B5227414F33C';
wwv_flow_api.g_varchar2_table(36) := 'B3F7EE6F1598B82F2C385FB5C58F322D7B01F0E0AA1215CBC358B5C50FEDF2798CDF9763E2BE1C0FAE2A5931CDAA2D7ED4AE0F42AEA451B13C16EB4DDC9723E41731E5437E71C6BA6BD70720574651D9108AF5594004F7B00C21BF087DBF2AE5B5633E0D';
wwv_flow_api.g_varchar2_table(37) := '63C99534D67C8642654388B1C93D22C5EFCF97C13DB2A8C9A4CE062C653E0376A1A0EAEFEF079DD40909A0F97C3ED4D5D565D54110043C1E4F665718A1B114BF50DFECC3B25521D6B9202502B97BA1DE159BC230AC0C30C05AB999C2A6D659C8140B7547';
wwv_flow_api.g_varchar2_table(38) := 'E2D8D4D7C77274C6263FD6EDF0A2BBA31CFDD7084EA0FDE9BF70B3EA4D5C2F9601FAFA08A363B857815FBFCFE6053E9B2B8C617C6AEF344A2BD893C4A80EC3D8E4C7AFDFD762B85791EB70CB85AC0AF3E2064B4A4A0495733A9D2C50250B455108040250';
wwv_flow_api.g_varchar2_table(39) := '28321B2A97CBB3C41A51CCF374725DB30FFA9541FE76F59760F24149461D1BBE308DF9942CC6CDF3B1C9BBA2D987E657A763CC9125D32192D1687ED50D3A1AC5E0F50596DFFC27D3D0AE0864BD1E00AAD65058BB5D8ADB17CB17188BC7E60D5FC8DCA68D';
wwv_flow_api.g_varchar2_table(40) := '7F3C8DE1DEEA258F7FC1D6D36281E0CC167847229125B7259286B16A37CE6508DCD529C04AC37AC9B604C418E95582A898C786CF4FF396770E94809A96A28EF47107FDF3D318E955221C1043A6A05165F621D97C6A468AEB3FD522EC1763CD4B1E189BFC';
wwv_flow_api.g_varchar2_table(41) := '6C97F9FC2C06AE13A0A6A569192B2B2194D330AC0CC0D9AFC83FB0F2B57210A287204AE1F35169579504519A554F3018CA582612E167AC6C2C97AC33930E87B50CE18018D4B41421BF188D2FCE40249BE7B042D7B12AB80662033670AD142DFBC739CC55';
wwv_flow_api.g_varchar2_table(42) := '6B99C3838FCB515E15E2D4371FA111A4C4F08CC971ED7F75309173F08CC5D8DA3326473820E694E713CF981CAE0105AA9B28101A6E7E4F52422F19030563AC7058584252ABADC0D4D414AF3B149AAAA0282A0BEBD1989FCF0D58A9399F743A7EF37E35A6';
wwv_flow_api.g_varchar2_table(43) := '06D9A1698589E2949D1D9733A00200D780025E9718CA9481ADA8F3031F97C33326E7E8909785B0ED2BC30000FF8C14D48C140A7509A606141C5001E06DEFF00D156EB41B000033A3323CDBEAE4C6C795418C7D421402584BA7AC40C00FB5BA5C90CB341A';
wwv_flow_api.g_varchar2_table(44) := 'AB313C3CCC0E268D46A8546559DB12CB63851615638DDC54C13FC3DF056E7B09AB6E3E1D7E8F1453830A4E1B0903372E220C01ECFAD67DEEE0A79413CBE70144110E8830FA8912CB1A7DFC6CAE0A41AD0A415D4BA17633E09D90E3EA07CB5900E3B3D9D9';
wwv_flow_api.g_varchar2_table(45) := 'BF60976B40C15B2636C9A38F276379BD5EC18CA352A950595989898909C86432D4D4D4640DD893837F2131165F070EDF5061DA2E6C21CCA763CECD9F0A995F446CC3B0926A613161FD49159ED9EE8469CB4CD6EB94FA005E383080AEF7EA311F07175F3B';
wwv_flow_api.g_varchar2_table(46) := 'A8A489E49F91F2032B0FB150015D61181E8F47F0B68B56AB854422C96993DAED766775838944215F209B4B669D4F075F0232968600A42529F151508CB989DC03E2BB170D18FD7D392A4C1434260A65CB8250A8F9173C22290DFD6A2FC66FA9D306EFA936';
wwv_flow_api.g_varchar2_table(47) := 'F396A11F636025D82417A0E4523610080862AB4C8C95CBC4E4D3E1B6F303656A50095D8337056C12F49CACCD7D804A2290C823981D2F81DBAE846F52016949046A1385BAE75D285DC6BE674DDBB0002C21363F718C95602D97CB05BD5E9F77373B3A3A9A';
wwv_flow_api.g_varchar2_table(48) := '36FFC51788F32FBD73602C1E1DE936755D77CBA0A967276CA5A54198773B30F0513582B332549353A8FF6C6C5518094AE073C6403A795B83C9DB1A3CFB670F506A6083261294E0C68F5621382BC3D43D15CA97FBA0D0B1193BD9B50BB139C21B633DE6C0';
wwv_flow_api.g_varchar2_table(49) := '4AB056595999E098299B4C4C4CC0ED76E79CC79AA7F3C058293AD2CDECC9DB1A2CDBE80491028CF27A0F9E4D021CB36893D1208C614482124CDD8FB19AEB5E194A524003198D67F7D9E01D2E85BC3C8492F23052177EEEFBAA24FD02188B7E888C95EF4D';
wwv_flow_api.g_varchar2_table(50) := 'FDA1A1613434342C719519C0D8D8D8A26E574EB7094D47A3826DE5D311A5D3F7D5DDB37558DB760F12B9B0046F242481ED67F5980FC4160463563DD4F51E107AAEBDA5D573F1182F8529FB2A10F0C833C680A936F36E54D3787CF3588954824EA78356BB';
wwv_flow_api.g_varchar2_table(51) := 'B4BD6D97CB25389E4AEBC6F8DC6674693A32CDECE0AC1C37DF37A366DB0874E6CC0C3B65D362EC6A1542B37296DBB3FD6C156AB68D40B3D29311A021AF1C6357AB30D5A7E5B06C369B2305622CD6ADC916926C03704204D192156BB55A180C06C15B3B99';
wwv_flow_api.g_varchar2_table(52) := 'C4E3F1607474144FAA484A2250EAFD90AB424C3A21E42D41C82B87DFA5442498FDD6A2B2E57390C82350EA17DCE3DCA80A91A0047E97F291DA1745143D56ABA8A08C2593C960341A411044DE7426568B7CE04A0097A6E9C7165891A00473234B7B2B41E2';
wwv_flow_api.g_varchar2_table(53) := '7ACF80FA89984C79059642A1405D5D5D5E588A0F5C252525B0DBED2C10E9743AE8F57A84C361E66E88C4DFA23C76C08A2E12542688C5220085B9A557A128415D9D8905AED8B651143299146A75396B1B89A228E6F0F97C0FBD73E572399E7986FF453C93';
wwv_flow_api.g_varchar2_table(54) := '9393989C9C2858DDCB965562D9B2659CF3BDBDB7F25E9748F0AA7011417A5575354462B1E06B699A061D89402ACBED8EC51285020DAB57C36EB7432291402A93A5AD534910501204C46E37E61E01B0EA57AEC4860DCFF27E373D3D8DFFFBC5B982D55D59';
wwv_flow_api.g_varchar2_table(55) := '5989F5EB3770CEDF2A00B08433568EC8D26975509428045F47D334EC763B0281008C4663CECF1A8A4562D499EA40D3114175CECC780A45A219A56155439CC179FA4CA745596919E6E6E60A52B74824E2AFFB21F5C3928321B1589C533A617E3E8C7BF7EE';
wwv_flow_api.g_varchar2_table(56) := '3131D0E8E868C6DB8A33D52B95CA04D5F728E22DAD560B9D4E0FB15892F6686A6A2A58FD316071EB7C58B2646069349A9C82F5A1A161CE0A6E7474142E97AB2006CECC78F02864F5EAD59048C4198F152B561414587C753E31AB42A10F4D00B1EC793AF6';
wwv_flow_api.g_varchar2_table(57) := '703A9D088542301A8D79338EA6694C4D4D3D126035369AB3324479B91A75752B60B70F660E35743A545757432EE73E4760B70FF2DA28128933D65F5D5D0D9D4EC7E84CA767B1D17B9A2D1DE18E38F6D084B0F25EAF37A3EE99991984C3E1F893D34B9F5D';
wwv_flow_api.g_varchar2_table(58) := '53535379B9673EE7A0BDBE1E4A253B69190A85E0F57AA1D3E93865070707D2F66D7373336F109E90CD9B37637474141F7DF44BD62B07628C25E105E9E73EF722A71D9B376FC69D3B77F0D147BF5C143B0A7285D16854F021168B118D42E0915DDFDCDC1C';
wwv_flow_api.g_varchar2_table(59) := '060707110A8573D0CB3DE6E72370B95C39D992AF63CD9A35904A25AC637C7C0C77EFDEE19C5FBBB60972B99C57CFDEBD7B61B15838D7A41E26532DF6ECD9C3D223168B78CBEED9B3079595CB78BF5BBBB60966B339677B05C7586289181089041E107CA8';
wwv_flow_api.g_varchar2_table(60) := '542A413A03C1201EF4F7C3475139E94F3EE86834071BF277942814F1F84AC23A060607D13F30C0392F9148B0AAA181A367554303341A0DAB9C8FA270EDFA75DCB97B17F3F3F3ACEF341A0D3EF5DC73CCF522B198B72EA552C97B3E71909B36E56E774E31';
wwv_flow_api.g_varchar2_table(61) := '96406F180ECD43261316AA29140AA8CA5482DE12434768D807ED301A8DD06872DFC69049A558DDB01AA3A3A382DF4A930F59B7761DA4526E7F3CB8FF00C160101445A1BC9CFD2CC0E6E6667C72FB13D6B96756AFE6E8B979E326BABBBB63F5AC5B8BB56B';
wwv_flow_api.g_varchar2_table(62) := 'D7C1E99C442010443018C4D0D010336E629198B71D00100C0693C29894D8ABAA2A2F29890C8810A63D10F04326131EC01B8DD5B0DB438252001A8D1AA5A58BDF739448C4A8ADAD81D7EBC5C8C8C843D94FDCB0613D27B6191A1A423018B3F7C18307686E';
wwv_flow_api.g_varchar2_table(63) := '6E667D5F555505B5BA9C9576713A9D1C3D2FBDF447D8B0613D262727E1F178F0C927B7E1703878D33562317F8CD5DBDB8B4B972E0100DADADA78B3F3B9234B94FF55A1D73B9BD3CA50229160E5CA95703A9D4CB0CE621A990C2A950A3A9D0E32597E5ECA';
wwv_flow_api.g_varchar2_table(64) := 'A152A9B07A75E1D9ABB2B212D5D5DCA788EFDFBFCF1AD8AD5BB772CA6CD9B205172F5E643EDFBB770F3B76ECE05DCDA5D6E1F17870FAF4694C4C4C640DDE3FFCF04386B186878779DBFB58A41B6667BDA8AC8CE4FC561983C10083C18070388C5028F6F8';
wwv_flow_api.g_varchar2_table(65) := '965C2ECF1B98F8005D5B5B0BB7DB8DF1F1F182D4B171E3465EF7B36BD72EECDAB52BE3B54D4D4D2C60793C1E9C3B770EBB77EFCE5AAF4EA7C397BFFC659C397306376FDE4C4A204B79533EC92BD574EEB260C0124A86119AC6F8C4388CC6E58B6B804CC6';
wwv_flow_api.g_varchar2_table(66) := 'DA2F2CE48E031D89607A66A660759024B9E8D73669B55A98CD66F4D96CCCB91B376F627C6202CF3FF71C56AC58018D469351C78B2FBE881B71602582F74CE32AA44CFE192B07ED33D31E10CAD2AC863F6A191CB4176C7BA7A9690DCACA4A97A463EDDAB5';
wwv_flow_api.g_varchar2_table(67) := 'E8EBB3B1CE8D8F8DE3E73F6F67163F466335EAEBEBB172653DEAEBEB5965F57A1DAAABAA31363606B128966EC834AE42CA3C3257C874C0F838148A1228140FEF6EC640C00F89442AC87D8E8E8E1474CF70F3E6E625BF646EF3E6669C3B770E0A85122D2D';
wwv_flow_api.g_varchar2_table(68) := '2F30BB10466335140A052E5DFA10172F5E427FFF003EFC103874E81D545468529295605C61B6F60829F3C88145D334FAFB07E2E981C232174D473035E586D3E964EEAB37180C69CBC7160A85DB33542A9558B76E3DE7FCF4F434E757B112D2DCDC8C8A8A';
wwv_flow_api.g_varchar2_table(69) := '0A1ED65A87DBB76F63CB962D9C279B76ECD801A592C0F4F4348C4623277B3E3D3D8DD1D1312678CFB6A524A44C0162ACC5F1E1C8E80866BDB3A8AAAACA7B204ED311B8A7DC7025BD4424424730E99CC4AC771646A391331833333398744E1614E831B6E2';
wwv_flow_api.g_varchar2_table(70) := 'E69A0706FAD179E1421AB60DA0B5951B987FF6B39FC6B5EBD7D0D5D5859D3B77F07E9F4EBABBBB99714B6C42671A5721651E3963B153105E78BD5EA8542A68341A9496128B9E19E170183E9F8FD199DE2D06D0DFDF8F650603B43A2DC462090281C04379';
wwv_flow_api.g_varchar2_table(71) := '0863EBD6ADBCF6DDEABD9DF69A5BBDBDD8B3670FE77C4D4D2DB45A2DCE7776422412655D4D26E4FCF9F338DFD999131B3D12C6421E9ED4F17AE7E0F5CE3181A7425102B94C0EA94CC6CB66344D23188F837C1405BFDF9F92D4CCDEA649A70BD3331EE874';
wwv_flow_api.g_varchar2_table(72) := '3A4C4E4EE6C58E6CD2DBDB8BDEDE5E9EFCD583B4F5BBDDD3E8E8E8E06C5627D2076EF7347E71BE13BFBB7A0DCF6E580FAD568B9A1AF6CA7BCAEDC6C8F0087EFBBBABF0FBFDACBAEE3F7880CE24A0F1F5A190328B15DEC7BF00E4FC3EA9A23CBD22958A73';
wwv_flow_api.g_varchar2_table(73) := '78FCEB097FC779511E31D8F290C62A4A51B8A98C621714E5E106EF45CA2A4A615C6111594529BAC2A23C2291CBA582182BB2545768362FFC26A22D69A7DE6432B15E14425114F3E34A7ABD9EF7AD7F0E87037ABD1E0441C0E572318F882574259F03623F';
wwv_flow_api.g_varchar2_table(74) := '7D6232B17FBC2CB90D4BB167A97A9E7657E8590AAECC6633DE39F416F3F9DD77DF83D5DA030078EDB5BD30AF61BFC7A0A3FD0C3ACE9CC50B2F3C8FD657B8DB1B478EFC1300E09D436F81A2287CE31BEF40AFD7E3DBDFF93BE673723B6B4D2656FD00E072';
wwv_flow_api.g_varchar2_table(75) := '4EE1C8778F2EFAB9C584BE37DE78B38896F4E2CE062CC752B493968DCC60EA0D3A90160B032C8641FAEE80A228909B2CD8B1733B3ACE9C6581A0ABAB6BE1739C91BA2E5F41CBB617D0BAFB6586913A3ACE667C637247FB19B4B4B4406FD0A1EDB5BD78F7';
wwv_flow_api.g_varchar2_table(76) := 'DFDFE3B090C3E160E9489C4F66C204B8139260D76436B5D96C309BCD0C0B9BCD660E9B26AEE3636A87C30193C9C49C4FD898DABE746C9A5A2EC1DCE9EA4A6E77A26C6A7B7314473660DD01E007A05C0C6791A4050070E1E245B4B5ED05B9C902FC20CAE2';
wwv_flow_api.g_varchar2_table(77) := '409BCD06C7D010C84D96B86B5CA8872855C26C5E60B58E33670000277FFC6306883170DA7081777337CABAD631348483070FC4DA81284C26130E1D7A9B71C91445E1D8B1E3B0D96C38F4CEDBD01BF4A07C14F4063D8E1D3B8EAEAE2E1C62186B1FCC6633';
wwv_flow_api.g_varchar2_table(78) := '0E1E3C008220626FB189977DE38D7D3874E82DB89CB181D11BF471501E85CD66C3FE37F7A1655B4BD2E4B2E1C8778FA225CED40EBB03A63A134E9E3C85D6D69741F92810F17BFD8F1C39CAF93DC6543B0030ED6D6969C1FEFDFB1646DCEE60D565EBB3C1';
wwv_flow_api.g_varchar2_table(79) := 'BCC6CC7CA737E8193D89F62E426E650CDE7BACD608805F326394C361AA35C5E2A428D075B90B0EBB03849200692117C63B0AB4B6EEC6C1AF1F00A2B10E4EFE8E5012309BCDCC91D04DF92838EC0EE6B3C331C4FC6F6E34C3DC6886A9D6C46913E5A3589F';
wwv_flow_api.g_varchar2_table(80) := '0F7EFD0008258193274EE1E48953209404DA5EDB0B53AD2936C37D142E5CB88493274EA1EB721747DF8EED2F31D71F397C94B13771E8F57A5CB87009D66E6BBC6D8D6879A1052D2D2DB1013E7C140E7B8CD15A5E6859B09B20F0EEBFBD0742A904A18CC5';
wwv_flow_api.g_varchar2_table(81) := '8E1DED6771ECFBC75976A7DA71E4F0517CEB6FFF1EB63E1B082501BD4E8FFD6FEE83CBE9C2D7BE7A00274F9C82C96442DB6B7B3975211A036847FB59567B731DF7B89C17926EF81180CFE7CA57C941FBF7BEB7E0762CE446745BAD1CF7E674B970F2E429';
wwv_flow_api.g_varchar2_table(82) := '56FB6C361B0E1F39CAD1BD8924195743100476ECD88ECE0B17E172B970E8D0DBCCB5ED1D6759DC9558105014C5FA4C921B5901799FCD86CE0B17B189B4A0AD6D2F5326B92DD1B88B0100BBC3017B128B24F755E7850B50124A90248928009D5EC7B8A7D6';
wwv_flow_api.g_varchar2_table(83) := 'D697415114536FE2BACB5D57D06DB5A2CF6643ADA9166B12130B407BC71974749CE1B8E344BB6365CE32EE38D1C73E8A62DAA8D7EBE174C51E9FEFB6F6B0C623B5BDB98CBB422103803900678500AB3D1008E7CC852D2DCFB38093F0DD9B4812C7709C29';
wwv_flow_api.g_varchar2_table(84) := '77B9EB0AA7A39229FE9B71A000C08993A7E072B9186A3F76EC381ACD8DD8B9633BBEB47F1F0E1F39CA0C7E027409F9E6A1B79958E572D715064866B31956EB0D5014859696E761B5DE88AF3295B8DC75055D5D57F02FFF7C94B3BA8C0DE41D98CD66BCDE';
wwv_flow_api.g_varchar2_table(85) := 'B6174E81F188CD7687695F7BC759A69FEC0E0703BA84AC8903E3D8B1E3200802FBF7EF83C9147B3DF707FF13EBC33F7F631F63C7CEF8533C6D6D7BE1703870F8C8515014C5F4BB253E81FAE26D2890FC778FD53A9715583D566BC84292AF07FCE1134235';
wwv_flow_api.g_varchar2_table(86) := 'EBF57A6620BEFFFDE3CC8CFCE08358076D2249761814E50F8D088260311FA124B0FFCD7D2008029D9D17D1DD6D4577B7156BCC8D4CC776765EE065CD04C35DBEDC858EF63340143871E2145E7F7D2FC34A0E87037D7DB6D844501278A5B505AFB4EE8EB9';
wwv_flow_api.g_varchar2_table(87) := 'A28EB3EC7646C1E859B3A6110EFBD0825D29E592DDBBADCF86F6F633D8B9733BBE79E8ED789BAEC0617780B45858D7389D2E18F47A1C3C7880695F473BB71D274EC462B1841D369B0D274E9C02E5A370F8F0517CE94BFB70F0E001501485CECE8BE8683F';
wwv_flow_api.g_varchar2_table(88) := 'B370536134737B85529642294BAC06FF91EF7B51BA67EF2D24F97300AF0080DF1F2A2EA8016CDBD602736323AC3D3DE8EBB3E1BFFEF33F405114BEF2D5BF7C6AFA40A964FD9AEDAB3D56EB692179AC64791DC0C700362A95F222B800D8ED0EBCDEF61AB6';
wwv_flow_api.g_varchar2_table(89) := '25ADF04E9CFCF1D30AAAEFA4035546C68AB3D67200BF00B0BEC85C0BEEBA2EEEF69D4BCBFD3CC9A07AAFC76AFD7AA6F2A26CEFC2B290A412C00F017C31168416C1F5744D2416A04200BED663B5FE20DB7522A12F59B390E42B00FE014053115C4F25A84E';
wwv_flow_api.g_varchar2_table(90) := '03F89B1EAB55D0125394CBDBFB2C242901F0729CBD7601D03EAD9DCE37B9520622AFD7E77332E7D0CE3B71409DEEB15A6FE452070B588DE6B5316DB6DB4281D600400DA0114059718EFF418803801380A3C76A5DF42F63E5C45845298A5029DEE8579422';
wwv_flow_api.g_varchar2_table(91) := 'B08A520456519E72F9FF01003D23B2D342E911AA0000000049454E44AE426082';
end;
/
begin
wwv_flow_api.create_theme_image(
  p_id =>21510225752853490 + wwv_flow_api.g_id_offset,
  p_flow_id =>wwv_flow.g_flow_id,
  p_theme_id  => wwv_flow.g_flow_theme_id,
  p_varchar2_table=> wwv_flow_api.g_varchar2_table,
  p_mimetype=> '');
end;
/
commit;
begin 
execute immediate 'begin dbms_session.set_nls( param => ''NLS_NUMERIC_CHARACTERS'', value => '''''''' || replace(wwv_flow_api.g_nls_numeric_chars,'''''''','''''''''''') || ''''''''); end;';
end;
/
set verify on
set feedback on
prompt  ...done
