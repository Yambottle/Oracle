var checkboxHeight="25";
var radioHeight="25";
var selectWidth="190";
document.write("<style type=\"text/css\">input.styled { display: none; } select.styled { position: relative; width: "+selectWidth+"px; opacity: 0; filter: alpha(opacity=0); z-index: 5; } .disabled { opacity: 0.5; filter: alpha(opacity=50); }</style>");
var Custom={init:function(){
var _1=document.getElementsByTagName("input"),_2=Array(),_3,_4,_5;
for(a=0;a<_1.length;a++){
if((_1[a].type=="checkbox"||_1[a].type=="radio")&&_1[a].className=="styled"){
_2[a]=document.createElement("span");
_2[a].className=_1[a].type;
if(_1[a].checked==true){
if(_1[a].type=="checkbox"){
position="0 -"+(checkboxHeight*2)+"px";
_2[a].style.backgroundPosition=position;
}else{
position="0 -"+(radioHeight*2)+"px";
_2[a].style.backgroundPosition=position;
}
}
_1[a].parentNode.insertBefore(_2[a],_1[a]);
_1[a].onchange=Custom.clear;
if(!_1[a].getAttribute("disabled")){
_2[a].onmousedown=Custom.pushed;
_2[a].onmouseup=Custom.check;
}else{
_2[a].className=_2[a].className+=" disabled";
}
}
}
_1=document.getElementsByTagName("select");
for(a=0;a<_1.length;a++){
if(_1[a].className=="styled"){
_4=_1[a].getElementsByTagName("option");
_5=_4[0].childNodes[0].nodeValue;
_3=document.createTextNode(_5);
for(b=0;b<_4.length;b++){
if(_4[b].selected==true){
_3=document.createTextNode(_4[b].childNodes[0].nodeValue);
}
}
_2[a]=document.createElement("span");
_2[a].className="select";
_2[a].id="select"+_1[a].name;
_2[a].appendChild(_3);
_1[a].parentNode.insertBefore(_2[a],_1[a]);
if(!_1[a].getAttribute("disabled")){
_1[a].onchange=Custom.choose;
}else{
_1[a].previousSibling.className=_1[a].previousSibling.className+=" disabled";
}
}
}
document.onmouseup=Custom.clear;
},pushed:function(){
element=this.nextSibling;
if(element.checked==true&&element.type=="checkbox"){
this.style.backgroundPosition="0 -"+checkboxHeight*3+"px";
}else{
if(element.checked==true&&element.type=="radio"){
this.style.backgroundPosition="0 -"+radioHeight*3+"px";
}else{
if(element.checked!=true&&element.type=="checkbox"){
this.style.backgroundPosition="0 -"+checkboxHeight+"px";
}else{
this.style.backgroundPosition="0 -"+radioHeight+"px";
}
}
}
},check:function(){
element=this.nextSibling;
if(element.checked==true&&element.type=="checkbox"){
this.style.backgroundPosition="0 0";
element.checked=false;
}else{
if(element.type=="checkbox"){
this.style.backgroundPosition="0 -"+checkboxHeight*2+"px";
}else{
this.style.backgroundPosition="0 -"+radioHeight*2+"px";
group=this.nextSibling.name;
inputs=document.getElementsByTagName("input");
for(a=0;a<inputs.length;a++){
if(inputs[a].name==group&&inputs[a]!=this.nextSibling){
inputs[a].previousSibling.style.backgroundPosition="0 0";
}
}
}
element.checked=true;
}
},clear:function(){
inputs=document.getElementsByTagName("input");
for(var b=0;b<inputs.length;b++){
if(inputs[b].type=="checkbox"&&inputs[b].checked==true&&inputs[b].className=="styled"){
inputs[b].previousSibling.style.backgroundPosition="0 -"+checkboxHeight*2+"px";
}else{
if(inputs[b].type=="checkbox"&&inputs[b].className=="styled"){
inputs[b].previousSibling.style.backgroundPosition="0 0";
}else{
if(inputs[b].type=="radio"&&inputs[b].checked==true&&inputs[b].className=="styled"){
inputs[b].previousSibling.style.backgroundPosition="0 -"+radioHeight*2+"px";
}else{
if(inputs[b].type=="radio"&&inputs[b].className=="styled"){
inputs[b].previousSibling.style.backgroundPosition="0 0";
}
}
}
}
}
},choose:function(){
option=this.getElementsByTagName("option");
for(d=0;d<option.length;d++){
if(option[d].selected==true){
document.getElementById("select"+this.name).childNodes[0].nodeValue=option[d].childNodes[0].nodeValue;
}
}
}};
window.onload=Custom.init;

