$(function(){ 
	$('select.selectlist').wrap('<span class="select" />');
});